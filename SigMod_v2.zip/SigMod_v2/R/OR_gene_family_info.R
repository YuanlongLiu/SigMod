## this function stores the information of the Olfactory receptors (OR) gene family
## the OR gene family data and description can be found here: http://www.genenames.org/cgi-bin/genefamilies/set/141
## The genes of the OR gene family form a hug hairball structure (a set of genes with many interconnections) in the STRING network. It can hamper the power of the SigMod method. We suggest to remove these genes from the STRING network if they are apparently irrelevant to the phenotype under study

OR_gene_family_info <- function( save_to_local=FALSE )
{
OR_info = "HGNC ID	Approved Symbol	Approved Name	Status	Previous Symbols	Synonyms	Chromosome	Accession Numbers	RefSeq IDs	Gene Family Tag	Gene family description	Gene family ID
8179	OR1A1	olfactory receptor family 1 subfamily A member 1	Approved		OR17-7	17p13.3	AF087918	NM_014565	OR1	Olfactory receptors, family 1	147
8180	OR1A2	olfactory receptor family 1 subfamily A member 2	Approved		OR17-6	17p13.3	AF155225	NM_012352	OR1	Olfactory receptors, family 1	147
14750	OR1AA1P	olfactory receptor family 1 subfamily AA member 1 pseudogene	Approved			Xq26.2			OR1	Olfactory receptors, family 1	147
15390	OR1AB1P	olfactory receptor family 1 subfamily AB member 1 pseudogene	Approved			19p13.12	AC008894	NG_004627	OR1	Olfactory receptors, family 1	147
31243	OR1AC1P	olfactory receptor family 1 subfamily AC member 1 pseudogene	Approved			17p13.3			OR1	Olfactory receptors, family 1	147
8181	OR1B1	olfactory receptor family 1 subfamily B member 1 (gene/pseudogene)	Approved		OR9-B	9q33.2	AC006313	NM_001004450	OR1	Olfactory receptors, family 1	147
8182	OR1C1	olfactory receptor family 1 subfamily C member 1	Approved		TPCR27, HSTPCR27	1q44	X89674		OR1	Olfactory receptors, family 1	147
8183	OR1D2	olfactory receptor family 1 subfamily D member 2	Approved	OLFR1	OR17-4	17p13.3	U04678	NM_002548	OR1	Olfactory receptors, family 1	147
8184	OR1D3P	olfactory receptor family 1 subfamily D member 3 pseudogene	Approved	OR1D6P, OR1D7P	OR17-23, OR11-13, OR11-22	17p13.3	U04679		OR1	Olfactory receptors, family 1	147
8185	OR1D4	olfactory receptor family 1 subfamily D member 4 (gene/pseudogene)	Approved		OR17-30	17p13.3	U04681	NM_003552	OR1	Olfactory receptors, family 1	147
8186	OR1D5	olfactory receptor family 1 subfamily D member 5	Approved		OR17-31	17p13.3	AF087923	NM_014566	OR1	Olfactory receptors, family 1	147
8189	OR1E1	olfactory receptor family 1 subfamily E member 1	Approved	OR1E9P, OR1E5, OR1E6	OR17-2, HGM071, OR17-32, OR13-66	17p13.3	U04642	NM_003553	OR1	Olfactory receptors, family 1	147
8190	OR1E2	olfactory receptor family 1 subfamily E member 2	Approved	OR1E4	OR17-93, OR17-135	17p13.2	U04686		OR1	Olfactory receptors, family 1	147
8191	OR1E3	olfactory receptor family 1 subfamily E member 3 (gene/pseudogene)	Approved	OR1E3P	OR17-210	17p13.3	U04690	NG_002151	OR1	Olfactory receptors, family 1	147
8194	OR1F1	olfactory receptor family 1 subfamily F member 1	Approved	OR1F4, OR1F6, OR1F7, OR1F8, OR1F9, OR1F5, OR1F10, OR1F13P	Olfmf, OR16-36, OR16-37, OR16-88, OR16-89, OR16-90, OLFMF, OR3-145	16p13.3	Y14442		OR1	Olfactory receptors, family 1	147
13964	OR1F12	olfactory receptor family 1 subfamily F member 12	Approved	OR1F12P	hs6M1-35P, OR1F12Q	6p22.1			OR1	Olfactory receptors, family 1	147
8196	OR1F2P	olfactory receptor family 1 subfamily F member 2 pseudogene	Approved	OR1F3P, OR1F2	OLFMF2	16p13.3	AJ003145	NR_002169	OR1	Olfactory receptors, family 1	147
8204	OR1G1	olfactory receptor family 1 subfamily G member 1	Approved	OR1G2	OR17-209	17p13.3	U04689		OR1	Olfactory receptors, family 1	147
8206	OR1H1P	olfactory receptor family 1 subfamily H member 1 pseudogene	Approved	OR1H1	OST26	9q33.2		NG_004138	OR1	Olfactory receptors, family 1	147
8207	OR1I1	olfactory receptor family 1 subfamily I member 1	Approved		OR1I1P, OR19-20, OR1I1Q	19p13.1	AC004794		OR1	Olfactory receptors, family 1	147
8208	OR1J1	olfactory receptor family 1 subfamily J member 1	Approved		hg32	9q33.2	AL353767		OR1	Olfactory receptors, family 1	147
8209	OR1J2	olfactory receptor family 1 subfamily J member 2	Approved	OR1J3, OR1J5	OST044	9q33.2			OR1	Olfactory receptors, family 1	147
8211	OR1J4	olfactory receptor family 1 subfamily J member 4	Approved		HTPCRX01, HSHTPCRX01	9q33.2	X64979		OR1	Olfactory receptors, family 1	147
8212	OR1K1	olfactory receptor family 1 subfamily K member 1	Approved		hg99, MNAB	9q33	AL359512		OR1	Olfactory receptors, family 1	147
8213	OR1L1	olfactory receptor family 1 subfamily L member 1	Approved	OR1L2	OR9-C	9q33.2			OR1	Olfactory receptors, family 1	147
8215	OR1L3	olfactory receptor family 1 subfamily L member 3	Approved		OR9-D	9q33.2			OR1	Olfactory receptors, family 1	147
8216	OR1L4	olfactory receptor family 1 subfamily L member 4	Approved	OR1L5	OR9-E	9q33.2			OR1	Olfactory receptors, family 1	147
8218	OR1L6	olfactory receptor family 1 subfamily L member 6	Approved	OR1L7		9q33.2			OR1	Olfactory receptors, family 1	147
15110	OR1L8	olfactory receptor family 1 subfamily L member 8	Approved			9q33.2			OR1	Olfactory receptors, family 1	147
8220	OR1M1	olfactory receptor family 1 subfamily M member 1	Approved		OR19-6	19p13.2			OR1	Olfactory receptors, family 1	147
31244	OR1M4P	olfactory receptor family 1 subfamily M member 4 pseudogene	Approved			19p13.2		NG_004407	OR1	Olfactory receptors, family 1	147
8221	OR1N1	olfactory receptor family 1 subfamily N member 1	Approved	OR1N3	OR1-26	9q33.2	U86216		OR1	Olfactory receptors, family 1	147
15111	OR1N2	olfactory receptor family 1 subfamily N member 2	Approved			9q33.2			OR1	Olfactory receptors, family 1	147
8222	OR1P1	olfactory receptor family 1 subfamily P member 1 (gene/pseudogene)	Approved	OR1P1P	OR17-208	17p13.3	AF087927	NG_002153	OR1	Olfactory receptors, family 1	147
8223	OR1Q1	olfactory receptor family 1 subfamily Q member 1	Approved	OR1Q2, OR1Q3	OST226, OR9-A, HSTPCR106, OST226OR9-A, TPCR106	9q33.2			OR1	Olfactory receptors, family 1	147
8226	OR1R1P	olfactory receptor family 1 subfamily R member 1 pseudogene	Approved	OR20A1P, OR1R2P, OR1R3P	OR17-1	17p13.3			OR1	Olfactory receptors, family 1	147
8227	OR1S1	olfactory receptor family 1 subfamily S member 1 (gene/pseudogene)	Approved		OST034	11q12.1	BK004299	NM_001004458	OR1	Olfactory receptors, family 1	147
15141	OR1S2	olfactory receptor family 1 subfamily S member 2	Approved			11q12.1	BK004297	NM_001004459	OR1	Olfactory receptors, family 1	147
15062	OR1X1P	olfactory receptor family 1 subfamily X member 1 pseudogene	Approved			5q35.2	AC008454	NG_004630	OR1	Olfactory receptors, family 1	147
31245	OR1X5P	olfactory receptor family 1 subfamily X member 5 pseudogene	Approved			5q35.3			OR1	Olfactory receptors, family 1	147
8161	OR10A2	olfactory receptor family 10 subfamily A member 2	Approved	OR10A2P	OST363	11p15.4	BK004293	NM_001004460	OR10	Olfactory receptors, family 10	157
8162	OR10A3	olfactory receptor family 10 subfamily A member 3	Approved		HTPCRX12, HSHTPCRX12	11p15.4	BK004404	NM_001003745	OR10	Olfactory receptors, family 10	157
15130	OR10A4	olfactory receptor family 10 subfamily A member 4	Approved	OR10A4P		11p15.4	AF209506	NM_207186	OR10	Olfactory receptors, family 10	157
15131	OR10A5	olfactory receptor family 10 subfamily A member 5	Approved	OR10A1	OR11-403, JCG6	11p15.4	AF324499	NM_178168	OR10	Olfactory receptors, family 10	157
15132	OR10A6	olfactory receptor family 10 subfamily A member 6 (gene/pseudogene)	Approved			11p15.4	AB065515	NM_001004461	OR10	Olfactory receptors, family 10	157
15329	OR10A7	olfactory receptor family 10 subfamily A member 7	Approved			12q13.2	BK004327		OR10	Olfactory receptors, family 10	157
14989	OR10AA1P	olfactory receptor family 10 subfamily AA member 1 pseudogene	Approved			1q23.1			OR10	Olfactory receptors, family 10	157
14804	OR10AB1P	olfactory receptor family 10 subfamily AB member 1 pseudogene	Approved			11p15.4			OR10	Olfactory receptors, family 10	157
14758	OR10AC1	olfactory receptor family 10 subfamily AC member 1 (gene/pseudogene)	Approved	OR10AC1P		7q35			OR10	Olfactory receptors, family 10	157
14819	OR10AD1	olfactory receptor family 10 subfamily AD member 1	Approved	OR10AD1P		12q13.11			OR10	Olfactory receptors, family 10	157
14990	OR10AE1P	olfactory receptor family 10 subfamily AE member 1 pseudogene	Approved	OR10AE2P		1q23.2			OR10	Olfactory receptors, family 10	157
31235	OR10AE3P	olfactory receptor family 10 subfamily AE member 3 pseudogene	Approved			12q13.2			OR10	Olfactory receptors, family 10	157
19606	OR10AF1P	olfactory receptor family 10 subfamily AF member 1 pseudogene	Approved			11q12		NG_004298	OR10	Olfactory receptors, family 10	157
19607	OR10AG1	olfactory receptor family 10 subfamily AG member 1	Approved			11q12.1	AB065594	NM_001005491	OR10	Olfactory receptors, family 10	157
19647	OR10AH1P	olfactory receptor family 10 subfamily AH member 1 pseudogene	Approved			7p22.1		NG_004397	OR10	Olfactory receptors, family 10	157
31236	OR10AK1P	olfactory receptor family 10 subfamily AK member 1 pseudogene	Approved			11q			OR10	Olfactory receptors, family 10	157
8163	OR10B1P	olfactory receptor family 10 subfamily B member 1 pseudogene	Approved	OR10B2		19p13.12	AC003956		OR10	Olfactory receptors, family 10	157
8165	OR10C1	olfactory receptor family 10 subfamily C member 1 (gene/pseudogene)	Approved	OR10C2	hs6M1-17, OR10C1P	6p22.1			OR10	Olfactory receptors, family 10	157
8166	OR10D1P	olfactory receptor family 10 subfamily D member 1 pseudogene	Approved	OR10D2P	OST074, HTPCRX03	11q24.2	X64981		OR10	Olfactory receptors, family 10	157
8168	OR10D3	olfactory receptor family 10 subfamily D member 3 (putative)	Approved	OR10D3P	HTPCRX09	11q24.2	X64983		OR10	Olfactory receptors, family 10	157
14770	OR10D4P	olfactory receptor family 10 subfamily D member 4 pseudogene	Approved	OR10D4, OR10D6P		11q24.2			OR10	Olfactory receptors, family 10	157
14838	OR10D5P	olfactory receptor family 10 subfamily D member 5 pseudogene	Approved			11q24.2			OR10	Olfactory receptors, family 10	157
8169	OR10G1P	olfactory receptor family 10 subfamily G member 1 pseudogene	Approved			14q11.2			OR10	Olfactory receptors, family 10	157
8170	OR10G2	olfactory receptor family 10 subfamily G member 2	Approved			14q11.2			OR10	Olfactory receptors, family 10	157
8171	OR10G3	olfactory receptor family 10 subfamily G member 3	Approved			14q11.2			OR10	Olfactory receptors, family 10	157
14809	OR10G4	olfactory receptor family 10 subfamily G member 4	Approved			11q24.2	AB065757	NM_001004462	OR10	Olfactory receptors, family 10	157
14811	OR10G5P	olfactory receptor family 10 subfamily G member 5 pseudogene	Approved			11q24.2			OR10	Olfactory receptors, family 10	157
14836	OR10G6	olfactory receptor family 10 subfamily G member 6	Approved	OR10G6P	OR10G6Q	11q24.1	AB065508	NG_002255	OR10	Olfactory receptors, family 10	157
14842	OR10G7	olfactory receptor family 10 subfamily G member 7	Approved			11q24.2	AB065754	NM_001004463	OR10	Olfactory receptors, family 10	157
14845	OR10G8	olfactory receptor family 10 subfamily G member 8	Approved			11q24.2	AB065755	NM_001004464	OR10	Olfactory receptors, family 10	157
15129	OR10G9	olfactory receptor family 10 subfamily G member 9	Approved	OR10G10P		11q24.2	AB065756	NM_001001953	OR10	Olfactory receptors, family 10	157
8172	OR10H1	olfactory receptor family 10 subfamily H member 1	Approved			19p13.1	AC004510		OR10	Olfactory receptors, family 10	157
8173	OR10H2	olfactory receptor family 10 subfamily H member 2	Approved			19p13.1	AC004597		OR10	Olfactory receptors, family 10	157
8174	OR10H3	olfactory receptor family 10 subfamily H member 3	Approved			19p13.1			OR10	Olfactory receptors, family 10	157
15388	OR10H4	olfactory receptor family 10 subfamily H member 4	Approved			19p13.12	AC011517		OR10	Olfactory receptors, family 10	157
15389	OR10H5	olfactory receptor family 10 subfamily H member 5	Approved			19p13.12	AC011537		OR10	Olfactory receptors, family 10	157
8175	OR10J1	olfactory receptor family 10 subfamily J member 1	Approved		HGMP07J, HSHGMP07J	1q23.2	X64995	NM_012351	OR10	Olfactory receptors, family 10	157
14991	OR10J2P	olfactory receptor family 10 subfamily J member 2 pseudogene	Approved			1q23.2			OR10	Olfactory receptors, family 10	157
14992	OR10J3	olfactory receptor family 10 subfamily J member 3	Approved	OR10J3P		1q23.2			OR10	Olfactory receptors, family 10	157
15408	OR10J4	olfactory receptor family 10 subfamily J member 4 (gene/pseudogene)	Approved	OR10J4P	OST717	1q23.2			OR10	Olfactory receptors, family 10	157
14993	OR10J5	olfactory receptor family 10 subfamily J member 5	Approved			1q23.2		NM_001004469	OR10	Olfactory receptors, family 10	157
14994	OR10J6P	olfactory receptor family 10 subfamily J member 6 pseudogene	Approved	OR10J6		1q23.2			OR10	Olfactory receptors, family 10	157
19637	OR10J7P	olfactory receptor family 10 subfamily J member 7 pseudogene	Approved			1q23.2		NG_004365	OR10	Olfactory receptors, family 10	157
19638	OR10J8P	olfactory receptor family 10 subfamily J member 8 pseudogene	Approved			1q23.2		NG_004308	OR10	Olfactory receptors, family 10	157
19639	OR10J9P	olfactory receptor family 10 subfamily J member 9 pseudogene	Approved			1q23.2		NG_004366	OR10	Olfactory receptors, family 10	157
14693	OR10K1	olfactory receptor family 10 subfamily K member 1	Approved			1q23.1	AP002532		OR10	Olfactory receptors, family 10	157
14826	OR10K2	olfactory receptor family 10 subfamily K member 2	Approved			1q23.1	AB065642	NM_001004476	OR10	Olfactory receptors, family 10	157
14689	OR10N1P	olfactory receptor family 10 subfamily N member 1 pseudogene	Approved			11q24.2			OR10	Olfactory receptors, family 10	157
15378	OR10P1	olfactory receptor family 10 subfamily P member 1	Approved	OR10P1P, OR10P2P, OR10P3P	OST701	12q13.2	BK004259		OR10	Olfactory receptors, family 10	157
15134	OR10Q1	olfactory receptor family 10 subfamily Q member 1	Approved			11q12.1	AB065735	NM_001004471	OR10	Olfactory receptors, family 10	157
15135	OR10Q2P	olfactory receptor family 10 subfamily Q member 2 pseudogene	Approved			11q12.1			OR10	Olfactory receptors, family 10	157
14813	OR10R1P	olfactory receptor family 10 subfamily R member 1 pseudogene	Approved			1q23.1			OR10	Olfactory receptors, family 10	157
14820	OR10R2	olfactory receptor family 10 subfamily R member 2	Approved		OR10R2Q	1q23.1	AB065640	NM_001004472	OR10	Olfactory receptors, family 10	157
14829	OR10R3P	olfactory receptor family 10 subfamily R member 3 pseudogene	Approved			1q23.1			OR10	Olfactory receptors, family 10	157
14807	OR10S1	olfactory receptor family 10 subfamily S member 1	Approved			11q24.1	BK004509	NM_001004474	OR10	Olfactory receptors, family 10	157
14812	OR10T1P	olfactory receptor family 10 subfamily T member 1 pseudogene	Approved			1q23.1			OR10	Olfactory receptors, family 10	157
14816	OR10T2	olfactory receptor family 10 subfamily T member 2	Approved			1q23.1	AB065643	NM_001004475	OR10	Olfactory receptors, family 10	157
15332	OR10U1P	olfactory receptor family 10 subfamily U member 1 pseudogene	Approved			12q13.2			OR10	Olfactory receptors, family 10	157
15136	OR10V1	olfactory receptor family 10 subfamily V member 1	Approved			11q12.1	AB065807	NM_001005324	OR10	Olfactory receptors, family 10	157
15137	OR10V2P	olfactory receptor family 10 subfamily V member 2 pseudogene	Approved			11q12.1	AW847973		OR10	Olfactory receptors, family 10	157
15138	OR10V3P	olfactory receptor family 10 subfamily V member 3 pseudogene	Approved			11q12.1			OR10	Olfactory receptors, family 10	157
31237	OR10V7P	olfactory receptor family 10 subfamily V member 7 pseudogene	Approved			14q21.2			OR10	Olfactory receptors, family 10	157
15139	OR10W1	olfactory receptor family 10 subfamily W member 1	Approved	OR10W1P		11q12.1	AB065850	NM_207374	OR10	Olfactory receptors, family 10	157
14995	OR10X1	olfactory receptor family 10 subfamily X member 1 (gene/pseudogene)	Approved	OR10X1P		1q23.1	BK004194	NM_001004477	OR10	Olfactory receptors, family 10	157
15140	OR10Y1P	olfactory receptor family 10 subfamily Y member 1 pseudogene	Approved			11q12.1	AC021809		OR10	Olfactory receptors, family 10	157
14996	OR10Z1	olfactory receptor family 10 subfamily Z member 1	Approved			1q23.1	AB065635	NM_001004478	OR10	Olfactory receptors, family 10	157
8176	OR11A1	olfactory receptor family 11 subfamily A member 1	Approved	OR11A2	hs6M1-18	6p22.2-p21.31			OR11	Olfactory receptors, family 11	159
15345	OR11G1P	olfactory receptor family 11 subfamily G member 1 pseudogene	Approved			14q11.2			OR11	Olfactory receptors, family 11	159
15346	OR11G2	olfactory receptor family 11 subfamily G member 2	Approved			14q11.2			OR11	Olfactory receptors, family 11	159
15404	OR11H1	olfactory receptor family 11 subfamily H member 1	Approved		OR22-1	22q11.1	AP000535, AF399611	NM_001005239	OR11	Olfactory receptors, family 11	159
30738	OR11H12	olfactory receptor family 11 subfamily H member 12	Approved			14q11.2		NM_001013354	OR11	Olfactory receptors, family 11	159
29997	OR11H13P	olfactory receptor family 11 subfamily H member 13 pseudogene	Approved			14q11.2			OR11	Olfactory receptors, family 11	159
14716	OR11H2	olfactory receptor family 11 subfamily H member 2	Approved	OR11H2P, OR11H8P, C14orf15		14q11.2	AB065607, BK004489	NM_001197287	OR11	Olfactory receptors, family 11	159
15367	OR11H3P	olfactory receptor family 11 subfamily H member 3 pseudogene	Approved			15q11.2			OR11	Olfactory receptors, family 11	159
15347	OR11H4	olfactory receptor family 11 subfamily H member 4	Approved			14q11.2			OR11	Olfactory receptors, family 11	159
15348	OR11H5P	olfactory receptor family 11 subfamily H member 5 pseudogene	Approved			14q11.2			OR11	Olfactory receptors, family 11	159
15349	OR11H6	olfactory receptor family 11 subfamily H member 6	Approved			14q11.2			OR11	Olfactory receptors, family 11	159
15350	OR11H7	olfactory receptor family 11 subfamily H member 7 (gene/pseudogene)	Approved	OR11H7P		14q11.2			OR11	Olfactory receptors, family 11	159
14997	OR11I1P	olfactory receptor family 11 subfamily I member 1 pseudogene	Approved	OR11I2P		1p13.3	AC025375		OR11	Olfactory receptors, family 11	159
15369	OR11J1P	olfactory receptor family 11 subfamily J member 1 pseudogene	Approved			15q11.2			OR11	Olfactory receptors, family 11	159
15370	OR11J2P	olfactory receptor family 11 subfamily J member 2 pseudogene	Approved			15q11.2	AC021585		OR11	Olfactory receptors, family 11	159
31238	OR11J5P	olfactory receptor family 11 subfamily J member 5 pseudogene	Approved			15q11.2			OR11	Olfactory receptors, family 11	159
15371	OR11K1P	olfactory receptor family 11 subfamily K member 1 pseudogene	Approved			15q11.2			OR11	Olfactory receptors, family 11	159
19635	OR11K2P	olfactory receptor family 11 subfamily K member 2 pseudogene	Approved			14p13			OR11	Olfactory receptors, family 11	159
14998	OR11L1	olfactory receptor family 11 subfamily L member 1	Approved			1q44	AB065646	NM_001001959	OR11	Olfactory receptors, family 11	159
15333	OR11M1P	olfactory receptor family 11 subfamily M member 1 pseudogene	Approved			12q13.11	AC009775		OR11	Olfactory receptors, family 11	159
19582	OR11N1P	olfactory receptor family 11 subfamily N member 1 pseudogene	Approved			Xq26.2		NG_004381	OR11	Olfactory receptors, family 11	159
19636	OR11P1P	olfactory receptor family 11 subfamily P member 1 pseudogene	Approved			14q11		NG_004302	OR11	Olfactory receptors, family 11	159
31239	OR11Q1P	olfactory receptor family 11 subfamily Q member 1 pseudogene	Approved			Xq26.1			OR11	Olfactory receptors, family 11	159
8177	OR12D1	olfactory receptor family 12 subfamily D member 1 (gene/pseudogene)	Approved	OR12D1P	hs6M1-19	6p22.1			OR12	Olfactory receptors, family 12	160
8178	OR12D2	olfactory receptor family 12 subfamily D member 2 (gene/pseudogene)	Approved		hs6M1-20	6p22.1			OR12	Olfactory receptors, family 12	160
13963	OR12D3	olfactory receptor family 12 subfamily D member 3	Approved		hs6M1-27	6p22.1			OR12	Olfactory receptors, family 12	160
14772	OR13A1	olfactory receptor family 13 subfamily A member 1	Approved			10q11.21	AB065728	NM_001004297	OR13	Olfactory receptors, family 13	162
14699	OR13C1P	olfactory receptor family 13 subfamily C member 1 pseudogene	Approved			9q31.1			OR13	Olfactory receptors, family 13	162
14701	OR13C2	olfactory receptor family 13 subfamily C member 2	Approved			9q31.1		NM_001004481	OR13	Olfactory receptors, family 13	162
14704	OR13C3	olfactory receptor family 13 subfamily C member 3	Approved			9q31.1			OR13	Olfactory receptors, family 13	162
14722	OR13C4	olfactory receptor family 13 subfamily C member 4	Approved			9q31.1			OR13	Olfactory receptors, family 13	162
15100	OR13C5	olfactory receptor family 13 subfamily C member 5	Approved			9q31.1		NM_001004482	OR13	Olfactory receptors, family 13	162
15101	OR13C6P	olfactory receptor family 13 subfamily C member 6 pseudogene	Approved			9p13.3			OR13	Olfactory receptors, family 13	162
15102	OR13C7	olfactory receptor family 13 subfamily C member 7 (gene/pseudogene)	Approved	OR13C7P	OST706	9p13.3			OR13	Olfactory receptors, family 13	162
15103	OR13C8	olfactory receptor family 13 subfamily C member 8	Approved			9q31.1			OR13	Olfactory receptors, family 13	162
15104	OR13C9	olfactory receptor family 13 subfamily C member 9	Approved			9q31.1			OR13	Olfactory receptors, family 13	162
14695	OR13D1	olfactory receptor family 13 subfamily D member 1	Approved			9q31.1			OR13	Olfactory receptors, family 13	162
15105	OR13D2P	olfactory receptor family 13 subfamily D member 2 pseudogene	Approved			9q31.1			OR13	Olfactory receptors, family 13	162
15106	OR13D3P	olfactory receptor family 13 subfamily D member 3 pseudogene	Approved			9q31.1			OR13	Olfactory receptors, family 13	162
15107	OR13E1P	olfactory receptor family 13 subfamily E member 1 pseudogene	Approved	OR13E2	OST741	9p13.3			OR13	Olfactory receptors, family 13	162
14723	OR13F1	olfactory receptor family 13 subfamily F member 1	Approved			9q31.1			OR13	Olfactory receptors, family 13	162
14999	OR13G1	olfactory receptor family 13 subfamily G member 1	Approved			1q44	AB065623	NM_001005487	OR13	Olfactory receptors, family 13	162
14755	OR13H1	olfactory receptor family 13 subfamily H member 1	Approved			Xq26.2			OR13	Olfactory receptors, family 13	162
14732	OR13I1P	olfactory receptor family 13 subfamily I member 1 pseudogene	Approved	OR13I2P		9q31.1			OR13	Olfactory receptors, family 13	162
15108	OR13J1	olfactory receptor family 13 subfamily J member 1	Approved			9p13.3			OR13	Olfactory receptors, family 13	162
14721	OR13K1P	olfactory receptor family 13 subfamily K member 1 pseudogene	Approved			Xq26.2			OR13	Olfactory receptors, family 13	162
31240	OR13Z1P	olfactory receptor family 13 subfamily Z member 1 pseudogene	Approved			1q21.1			OR13	Olfactory receptors, family 13	162
31241	OR13Z2P	olfactory receptor family 13 subfamily Z member 2 pseudogene	Approved			1q21.1			OR13	Olfactory receptors, family 13	162
31242	OR13Z3P	olfactory receptor family 13 subfamily Z member 3 pseudogene	Approved			1q21.1			OR13	Olfactory receptors, family 13	162
15022	OR14A16	olfactory receptor family 14 subfamily A member 16	Approved	OR5AT1		1q44	BK004366	NM_001001966	OR14	Olfactory receptors, family 14	163
15024	OR14A2	olfactory receptor family 14 subfamily A member 2	Approved	OR5AX1P, OR5AX1		1q44	AB065620	NG_002409	OR14	Olfactory receptors, family 14	163
15026	OR14C36	olfactory receptor family 14 subfamily C member 36	Approved	OR5BF1		1q44	BK004466	NM_001001918	OR14	Olfactory receptors, family 14	163
19575	OR14I1	olfactory receptor family 14 subfamily I member 1	Approved	OR5BU1P, OR5BU1		1q44		NM_001004734	OR14	Olfactory receptors, family 14	163
13971	OR14J1	olfactory receptor family 14 subfamily J member 1	Approved	OR5U1	hs6M1-28	6p22.1			OR14	Olfactory receptors, family 14	163
15025	OR14K1	olfactory receptor family 14 subfamily K member 1	Approved	OR5AY1		1q44	BK004377	NM_001004732	OR14	Olfactory receptors, family 14	163
15023	OR14L1P	olfactory receptor family 14 subfamily L member 1 pseudogene	Approved	OR5AV1, OR5AV1P		1q44		NG_004286	OR14	Olfactory receptors, family 14	163
8229	OR2A1	olfactory receptor family 2 subfamily A member 1	Approved			7q35			OR2	Olfactory receptors, family 2	149
15082	OR2A12	olfactory receptor family 2 subfamily A member 12	Approved	OR2A12P		7q35			OR2	Olfactory receptors, family 2	149
15083	OR2A13P	olfactory receptor family 2 subfamily A member 13 pseudogene	Approved			7q35			OR2	Olfactory receptors, family 2	149
15084	OR2A14	olfactory receptor family 2 subfamily A member 14	Approved	OR2A14P, OR2A6	OST182	7q35			OR2	Olfactory receptors, family 2	149
15085	OR2A15P	olfactory receptor family 2 subfamily A member 15 pseudogene	Approved	OR2A28P		7q35			OR2	Olfactory receptors, family 2	149
8230	OR2A2	olfactory receptor family 2 subfamily A member 2	Approved	OR2A2P, OR2A17P	OST008	7q35			OR2	Olfactory receptors, family 2	149
15413	OR2A20P	olfactory receptor family 2 subfamily A member 20 pseudogene	Approved	OR2A20		7q35	AI084964		OR2	Olfactory receptors, family 2	149
19562	OR2A25	olfactory receptor family 2 subfamily A member 25	Approved	OR2A25P, OR2A27		7q35			OR2	Olfactory receptors, family 2	149
8231	OR2A3P	olfactory receptor family 2 subfamily A member 3 pseudogene	Approved			7q35			OR2	Olfactory receptors, family 2	149
14729	OR2A4	olfactory receptor family 2 subfamily A member 4	Approved	OR2A10		6q23.2	AC005587	NM_030908	OR2	Olfactory receptors, family 2	149
31246	OR2A41P	olfactory receptor family 2 subfamily A member 41 pseudogene	Approved			7q35			OR2	Olfactory receptors, family 2	149
31230	OR2A42	olfactory receptor family 2 subfamily A member 42	Approved			7q35			OR2	Olfactory receptors, family 2	149
8232	OR2A5	olfactory receptor family 2 subfamily A member 5	Approved	OR2A8, OR2A26	OR7-138, OR7-141	7q35	U86278		OR2	Olfactory receptors, family 2	149
8234	OR2A7	olfactory receptor family 2 subfamily A member 7	Approved		HSDJ0798C17	7q35			OR2	Olfactory receptors, family 2	149
8236	OR2A9P	olfactory receptor family 2 subfamily A member 9 pseudogene	Approved	OR2A9	HSDJ0798C17	7q35			OR2	Olfactory receptors, family 2	149
14749	OR2AD1P	olfactory receptor family 2 subfamily AD member 1 pseudogene	Approved		OR2AD1, hs6M1-8P	6p22.1	Z84476		OR2	Olfactory receptors, family 2	149
15087	OR2AE1	olfactory receptor family 2 subfamily AE member 1	Approved	OR2AE2		7q22.1	AC011904		OR2	Olfactory receptors, family 2	149
14719	OR2AF1P	olfactory receptor family 2 subfamily AF member 1 pseudogene	Approved	OR2AF2P		Xq26.2			OR2	Olfactory receptors, family 2	149
15142	OR2AG1	olfactory receptor family 2 subfamily AG member 1 (gene/pseudogene)	Approved	OR2AG3		11p15.4	AB065823	NM_001004489	OR2	Olfactory receptors, family 2	149
15143	OR2AG2	olfactory receptor family 2 subfamily AG member 2	Approved	OR2AG2P		11p15.4	AB065539	NM_001004490	OR2	Olfactory receptors, family 2	149
15144	OR2AH1P	olfactory receptor family 2 subfamily AH member 1 pseudogene	Approved			11q12.1			OR2	Olfactory receptors, family 2	149
15063	OR2AI1P	olfactory receptor family 2 subfamily AI member 1 pseudogene	Approved			5q35.3	AC025336		OR2	Olfactory receptors, family 2	149
15001	OR2AJ1	olfactory receptor family 2 subfamily AJ member 1	Approved	OR2AJ1P	OR2AJ1Q	1q44		NG_004652	OR2	Olfactory receptors, family 2	149
19569	OR2AK2	olfactory receptor family 2 subfamily AK member 2	Approved	OR2AK1P		1q44	BK004457	NM_001004491	OR2	Olfactory receptors, family 2	149
14712	OR2AL1P	olfactory receptor family 2 subfamily AL member 1 pseudogene	Approved			11q22.3	AC017094		OR2	Olfactory receptors, family 2	149
15113	OR2AM1P	olfactory receptor family 2 subfamily AM member 1 pseudogene	Approved			9p13.3			OR2	Olfactory receptors, family 2	149
31247	OR2AO1P	olfactory receptor family 2 subfamily AO member 1 pseudogene	Approved			7q35			OR2	Olfactory receptors, family 2	149
15335	OR2AP1	olfactory receptor family 2 subfamily AP member 1	Approved	OR2AP1P		12q13.2	BK004260		OR2	Olfactory receptors, family 2	149
15003	OR2AQ1P	olfactory receptor family 2 subfamily AQ member 1 pseudogene	Approved			1q23.1	AP002534		OR2	Olfactory receptors, family 2	149
15004	OR2AS1P	olfactory receptor family 2 subfamily AS member 1 pseudogene	Approved			1q44			OR2	Olfactory receptors, family 2	149
31248	OR2AS2P	olfactory receptor family 2 subfamily AS member 2 pseudogene	Approved			1q44			OR2	Olfactory receptors, family 2	149
15145	OR2AT1P	olfactory receptor family 2 subfamily AT member 1 pseudogene	Approved			11q13.4	AP001972		OR2	Olfactory receptors, family 2	149
19619	OR2AT2P	olfactory receptor family 2 subfamily AT member 2 pseudogene	Approved			11q13.4		NG_004337	OR2	Olfactory receptors, family 2	149
19620	OR2AT4	olfactory receptor family 2 subfamily AT member 4	Approved			11q13.4	BK004820	NM_001005285	OR2	Olfactory receptors, family 2	149
31249	OR2B11	olfactory receptor family 2 subfamily B member 11	Approved			1q44		NM_001004492	OR2	Olfactory receptors, family 2	149
13966	OR2B2	olfactory receptor family 2 subfamily B member 2	Approved	OR2B9	hs6M1-10, OR6-1, OR2B2Q	6p22.1	Z98744		OR2	Olfactory receptors, family 2	149
8238	OR2B3	olfactory receptor family 2 subfamily B member 3	Approved	OR2B3P	OR6-4	6p22.1			OR2	Olfactory receptors, family 2	149
8239	OR2B4P	olfactory receptor family 2 subfamily B member 4 pseudogene	Approved		hs6M1-22	6p22.2-p21.32			OR2	Olfactory receptors, family 2	149
8241	OR2B6	olfactory receptor family 2 subfamily B member 6	Approved	OR2B6P, OR2B1, OR2B1P, OR2B5	OR6-31, dJ408B20.2, OR5-40, OR5-41	6p22.1	U86275		OR2	Olfactory receptors, family 2	149
13967	OR2B7P	olfactory receptor family 2 subfamily B member 7 pseudogene	Approved		hs6M1-31P	6p22.1			OR2	Olfactory receptors, family 2	149
13968	OR2B8P	olfactory receptor family 2 subfamily B member 8 pseudogene	Approved	OR2B8	hs6M1-29P	6p22.1			OR2	Olfactory receptors, family 2	149
31250	OR2BH1P	olfactory receptor family 2 subfamily BH member 1 pseudogene	Approved			11p14.1			OR2	Olfactory receptors, family 2	149
8242	OR2C1	olfactory receptor family 2 subfamily C member 1	Approved	OR2C2P	OLFmf3	16p13.3	AF098664		OR2	Olfactory receptors, family 2	149
15005	OR2C3	olfactory receptor family 2 subfamily C member 3	Approved	OR2C4, OR2C5P	OST742	1q44	BC030717	NM_198074	OR2	Olfactory receptors, family 2	149
8244	OR2D2	olfactory receptor family 2 subfamily D member 2	Approved	OR2D1	OR11-610, hg27	11p15.4	AB065824	NM_003700	OR2	Olfactory receptors, family 2	149
15146	OR2D3	olfactory receptor family 2 subfamily D member 3	Approved			11p15.4	BK004294	NM_001004684	OR2	Olfactory receptors, family 2	149
15507	OR2E1P	olfactory receptor family 2 subfamily E member 1 pseudogene	Approved	OR2E1, OR2E2	hs6M1-9, hs6M1-9p, HS29K1, HSNH0569I24	6p22-p21.3	AC005678		OR2	Olfactory receptors, family 2	149
8246	OR2F1	olfactory receptor family 2 subfamily F member 1 (gene/pseudogene)	Approved	OR2F4, OR2F5, OR2F3, OR2F3P	OLF3, OR7-140, OR7-139, OR14-60	7q35	U56421		OR2	Olfactory receptors, family 2	149
8247	OR2F2	olfactory receptor family 2 subfamily F member 2	Approved		OR7-1	7q35			OR2	Olfactory receptors, family 2	149
8251	OR2G1P	olfactory receptor family 2 subfamily G member 1 pseudogene	Approved		OST619, hs6M1-25	6p22.2-p21.32			OR2	Olfactory receptors, family 2	149
15007	OR2G2	olfactory receptor family 2 subfamily G member 2	Approved			1q44	BK004472		OR2	Olfactory receptors, family 2	149
15008	OR2G3	olfactory receptor family 2 subfamily G member 3	Approved			1q44	BK004417		OR2	Olfactory receptors, family 2	149
27019	OR2G6	olfactory receptor family 2 subfamily G member 6	Approved			1q44		XM_372842	OR2	Olfactory receptors, family 2	149
8252	OR2H1	olfactory receptor family 2 subfamily H member 1	Approved	OR2H6, OR2H8	OR6-2	6p22.1	AF044491		OR2	Olfactory receptors, family 2	149
8253	OR2H2	olfactory receptor family 2 subfamily H member 2	Approved		hs6M1-12	6p22.1			OR2	Olfactory receptors, family 2	149
8255	OR2H4P	olfactory receptor family 2 subfamily H member 4 pseudogene	Approved		OR6-3, OR2H4, hs6M1-7, dJ80I19.6	6p22.2-p21.31			OR2	Olfactory receptors, family 2	149
8256	OR2H5P	olfactory receptor family 2 subfamily H member 5 pseudogene	Approved		OR2H5, hs6M1-13, HS271M21	6p22.2-p21.31	AF042075		OR2	Olfactory receptors, family 2	149
8258	OR2I1P	olfactory receptor family 2 subfamily I member 1 pseudogene	Approved	OR2I1, OR2I3P, OR2I4P, OR2I2	HS6M1-14	6p22.1	AC004179		OR2	Olfactory receptors, family 2	149
8259	OR2J1	olfactory receptor family 2 subfamily J member 1 (gene/pseudogene)	Approved	OR2J1P	OR6-5, hs6M1-4, dJ80I19.2	6p22.1		NG_004683	OR2	Olfactory receptors, family 2	149
8260	OR2J2	olfactory receptor family 2 subfamily J member 2	Approved		OR6-8, hs6M1-6, dJ80I19.4	6p22.1			OR2	Olfactory receptors, family 2	149
8261	OR2J3	olfactory receptor family 2 subfamily J member 3	Approved		OR6-6	6p22.1			OR2	Olfactory receptors, family 2	149
8262	OR2J4P	olfactory receptor family 2 subfamily J member 4 pseudogene	Approved		OR6-9, hs6M1-5, dJ80I19.5	6p22.2-p21.31			OR2	Olfactory receptors, family 2	149
8264	OR2K2	olfactory receptor family 2 subfamily K member 2	Approved	OR2AR1P	HTPCRH06, HSHTPCRH06	9q31.3	X64977	NM_205859	OR2	Olfactory receptors, family 2	149
19578	OR2L13	olfactory receptor family 2 subfamily L member 13	Approved	OR2L14		1q44	BC028158	NM_175911	OR2	Olfactory receptors, family 2	149
8265	OR2L1P	olfactory receptor family 2 subfamily L member 1 pseudogene	Approved	OR2L1, OR2L7P	HTPCRX02, HSHTPCRX02	1q44	X64980	NR_002145	OR2	Olfactory receptors, family 2	149
8266	OR2L2	olfactory receptor family 2 subfamily L member 2	Approved	OR2L4P, OR2L12	HTPCRH07, HSHTPCRH07	1q44	X64978	NM_001004686	OR2	Olfactory receptors, family 2	149
15009	OR2L3	olfactory receptor family 2 subfamily L member 3	Approved			1q44	AB065950	NM_001004687	OR2	Olfactory receptors, family 2	149
15011	OR2L5	olfactory receptor family 2 subfamily L member 5	Approved	OR2L11, OR2L5P		1q44			OR2	Olfactory receptors, family 2	149
15012	OR2L6P	olfactory receptor family 2 subfamily L member 6 pseudogene	Approved			1q44			OR2	Olfactory receptors, family 2	149
15014	OR2L8	olfactory receptor family 2 subfamily L member 8 (gene/pseudogene)	Approved			1q44	BK004459		OR2	Olfactory receptors, family 2	149
15015	OR2L9P	olfactory receptor family 2 subfamily L member 9 pseudogene	Approved			1q44			OR2	Olfactory receptors, family 2	149
8267	OR2M1P	olfactory receptor family 2 subfamily M member 1 pseudogene	Approved	OR2M1	OST037	1q44	AF308814	NR_002141	OR2	Olfactory receptors, family 2	149
8268	OR2M2	olfactory receptor family 2 subfamily M member 2	Approved		OST423, OR2M2Q	1q44	AF399616	NM_001004688	OR2	Olfactory receptors, family 2	149
8269	OR2M3	olfactory receptor family 2 subfamily M member 3	Approved	OR2M6, OR2M3P	OST003	1q44		NM_001004689	OR2	Olfactory receptors, family 2	149
8270	OR2M4	olfactory receptor family 2 subfamily M member 4	Approved		HTPCRX18, TPCR100, HSHTPCRX18, OST710	1q44	X64992	NM_017504	OR2	Olfactory receptors, family 2	149
19576	OR2M5	olfactory receptor family 2 subfamily M member 5	Approved	OR2M5P		1q44		NM_001004690	OR2	Olfactory receptors, family 2	149
19594	OR2M7	olfactory receptor family 2 subfamily M member 7	Approved			1q44	BK004486	NM_001004691	OR2	Olfactory receptors, family 2	149
8271	OR2N1P	olfactory receptor family 2 subfamily N member 1 pseudogene	Approved		OR6-7	6p22.2-p21.31	AJ132194		OR2	Olfactory receptors, family 2	149
8272	OR2P1P	olfactory receptor family 2 subfamily P member 1 pseudogene	Approved		hs6M1-26	6p22.1			OR2	Olfactory receptors, family 2	149
8273	OR2Q1P	olfactory receptor family 2 subfamily Q member 1 pseudogene	Approved		OR7-2	7q33-q35	AC004853		OR2	Olfactory receptors, family 2	149
8274	OR2R1P	olfactory receptor family 2 subfamily R member 1 pseudogene	Approved	OR2R1	OST058	7q35		NG_004373.2	OR2	Olfactory receptors, family 2	149
8275	OR2S1P	olfactory receptor family 2 subfamily S member 1 pseudogene	Approved		OST611	9p13.3			OR2	Olfactory receptors, family 2	149
8276	OR2S2	olfactory receptor family 2 subfamily S member 2 (gene/pseudogene)	Approved			9p13.3	AL135841	NM_019897	OR2	Olfactory receptors, family 2	149
8277	OR2T1	olfactory receptor family 2 subfamily T member 1	Approved		OR1-25	1q44	U86215		OR2	Olfactory receptors, family 2	149
19573	OR2T10	olfactory receptor family 2 subfamily T member 10	Approved			1q44		NM_001004693	OR2	Olfactory receptors, family 2	149
19574	OR2T11	olfactory receptor family 2 subfamily T member 11 (gene/pseudogene)	Approved		OR2T11Q	1q44	BK004476	NM_001001964	OR2	Olfactory receptors, family 2	149
19592	OR2T12	olfactory receptor family 2 subfamily T member 12	Approved			1q44	BK004485	NM_001004692	OR2	Olfactory receptors, family 2	149
14725	OR2T2	olfactory receptor family 2 subfamily T member 2	Approved	OR2T2P		1q44	BK004462	NM_001004136	OR2	Olfactory receptors, family 2	149
31252	OR2T27	olfactory receptor family 2 subfamily T member 27	Approved			1q44		NM_001001824	OR2	Olfactory receptors, family 2	149
31253	OR2T29	olfactory receptor family 2 subfamily T member 29	Approved			1q44		NM_001004694	OR2	Olfactory receptors, family 2	149
14727	OR2T3	olfactory receptor family 2 subfamily T member 3	Approved			1q44		NM_001005495	OR2	Olfactory receptors, family 2	149
31254	OR2T32P	olfactory receptor family 2 subfamily T member 32 pseudogene	Approved			1q44			OR2	Olfactory receptors, family 2	149
31255	OR2T33	olfactory receptor family 2 subfamily T member 33	Approved			1q44		NM_001004695	OR2	Olfactory receptors, family 2	149
31256	OR2T34	olfactory receptor family 2 subfamily T member 34	Approved			1q44	BK004477	NM_001001821	OR2	Olfactory receptors, family 2	149
31257	OR2T35	olfactory receptor family 2 subfamily T member 35	Approved			1q44	BK004475	NM_001001827	OR2	Olfactory receptors, family 2	149
15016	OR2T4	olfactory receptor family 2 subfamily T member 4	Approved		OR2T4Q	1q44	BK004464	NM_001004696	OR2	Olfactory receptors, family 2	149
15017	OR2T5	olfactory receptor family 2 subfamily T member 5	Approved			1q44	BK004465	NM_001004697	OR2	Olfactory receptors, family 2	149
15018	OR2T6	olfactory receptor family 2 subfamily T member 6	Approved	OR2T6P, OR2T9	OST703	1q44	AF399481	NM_001005471	OR2	Olfactory receptors, family 2	149
15019	OR2T7	olfactory receptor family 2 subfamily T member 7	Approved	OR2T7P	OST723	1q44			OR2	Olfactory receptors, family 2	149
15020	OR2T8	olfactory receptor family 2 subfamily T member 8	Approved	OR2T8P		1q44		NM_001005522	OR2	Olfactory receptors, family 2	149
8278	OR2U1P	olfactory receptor family 2 subfamily U member 1 pseudogene	Approved	OR2AU1P	hs6M1-24	6p22.2-p21.32		NM_001080842	OR2	Olfactory receptors, family 2	149
8279	OR2U2P	olfactory receptor family 2 subfamily U member 2 pseudogene	Approved		hs6M1-23	6p22.2-p21.32			OR2	Olfactory receptors, family 2	149
8280	OR2V1	olfactory receptor family 2 subfamily V member 1	Approved	OR2V1P	OST265	5q35.3	AB065465		OR2	Olfactory receptors, family 2	149
15341	OR2V2	olfactory receptor family 2 subfamily V member 2	Approved	OR2V3	OST713	5q35.3	AL161615		OR2	Olfactory receptors, family 2	149
8281	OR2W1	olfactory receptor family 2 subfamily W member 1	Approved		hs6M1-15	6p22.1	AL035402		OR2	Olfactory receptors, family 2	149
13970	OR2W2P	olfactory receptor family 2 subfamily W member 2 pseudogene	Approved		hs6M1-30P	6p22.1			OR2	Olfactory receptors, family 2	149
15021	OR2W3	olfactory receptor family 2 subfamily W member 3	Approved	OR2W8P, OR2W3P	OST718	1q44	N75737	NM_001001957	OR2	Olfactory receptors, family 2	149
15071	OR2W4P	olfactory receptor family 2 subfamily W member 4 pseudogene	Approved			6p22.1			OR2	Olfactory receptors, family 2	149
15424	OR2W5	olfactory receptor family 2 subfamily W member 5 (gene/pseudogene)	Approved	OR2W5P	OST722	1q44		NM_001004698	OR2	Olfactory receptors, family 2	149
15072	OR2W6P	olfactory receptor family 2 subfamily W member 6 pseudogene	Approved	OR2W7P		6p22.1	AL133267		OR2	Olfactory receptors, family 2	149
31258	OR2X1P	olfactory receptor family 2 subfamily X member 1 pseudogene	Approved			1q44			OR2	Olfactory receptors, family 2	149
14837	OR2Y1	olfactory receptor family 2 subfamily Y member 1	Approved			5q35.3	AB065676	XM_068682	OR2	Olfactory receptors, family 2	149
15391	OR2Z1	olfactory receptor family 2 subfamily Z member 1	Approved	OR2Z2		19p13.2	AC008753		OR2	Olfactory receptors, family 2	149
8282	OR3A1	olfactory receptor family 3 subfamily A member 1	Approved		OLFRA03, OR40, OR17-40	17p13.3	X80391		OR3	Olfactory receptors, family 3	150
8283	OR3A2	olfactory receptor family 3 subfamily A member 2	Approved		OLFRA04, OR228, OR17-228	17p13.3	U04713		OR3	Olfactory receptors, family 3	150
8284	OR3A3	olfactory receptor family 3 subfamily A member 3	Approved	OR3A6, OR3A7, OR3A8P	OR17-201, OR17-137, OR17-16	17p13.2	U04688		OR3	Olfactory receptors, family 3	150
15510	OR3A4P	olfactory receptor family 3 subfamily A member 4 pseudogene	Approved	OR3A4		17p13.3	BK004695	NM_001005334	OR3	Olfactory receptors, family 3	150
14839	OR3B1P	olfactory receptor family 3 subfamily B member 1 pseudogene	Approved			Xq28	AF277315		OR3	Olfactory receptors, family 3	150
25339	OR3D1P	olfactory receptor family 3 subfamily D member 1 pseudogene	Approved			1q44			OR3	Olfactory receptors, family 3	150
15147	OR4A10P	olfactory receptor family 4 subfamily A member 10 pseudogene	Approved	OR4A25P		11q11			OR4	Olfactory receptors, family 4	151
15148	OR4A11P	olfactory receptor family 4 subfamily A member 11 pseudogene	Approved			11q11	AC011829		OR4	Olfactory receptors, family 4	151
15149	OR4A12P	olfactory receptor family 4 subfamily A member 12 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15150	OR4A13P	olfactory receptor family 4 subfamily A member 13 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15151	OR4A14P	olfactory receptor family 4 subfamily A member 14 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15152	OR4A15	olfactory receptor family 4 subfamily A member 15	Approved			11q11	AB065776	NM_001005275	OR4	Olfactory receptors, family 4	151
15153	OR4A16	olfactory receptor family 4 subfamily A member 16	Approved		OR4A16Q	11q11	AB065519	NM_001005274	OR4	Olfactory receptors, family 4	151
15154	OR4A17P	olfactory receptor family 4 subfamily A member 17 pseudogene	Approved	OR4A22P		11q11			OR4	Olfactory receptors, family 4	151
15155	OR4A18P	olfactory receptor family 4 subfamily A member 18 pseudogene	Approved			11p11.12			OR4	Olfactory receptors, family 4	151
15156	OR4A19P	olfactory receptor family 4 subfamily A member 19 pseudogene	Approved			11p11.12			OR4	Olfactory receptors, family 4	151
8289	OR4A1P	olfactory receptor family 4 subfamily A member 1 pseudogene	Approved	OR4A20P	OR11-30	11p11.12	AF065869		OR4	Olfactory receptors, family 4	151
15158	OR4A21P	olfactory receptor family 4 subfamily A member 21 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15159	OR4A2P	olfactory receptor family 4 subfamily A member 2 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15160	OR4A3P	olfactory receptor family 4 subfamily A member 3 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
31259	OR4A40P	olfactory receptor family 4 subfamily A member 40 pseudogene	Approved			11p11.2			OR4	Olfactory receptors, family 4	151
31260	OR4A41P	olfactory receptor family 4 subfamily A member 41 pseudogene	Approved			11p11.2			OR4	Olfactory receptors, family 4	151
31261	OR4A42P	olfactory receptor family 4 subfamily A member 42 pseudogene	Approved			11p11.2			OR4	Olfactory receptors, family 4	151
31262	OR4A43P	olfactory receptor family 4 subfamily A member 43 pseudogene	Approved			11p11.2			OR4	Olfactory receptors, family 4	151
31263	OR4A44P	olfactory receptor family 4 subfamily A member 44 pseudogene	Approved			11p11.2			OR4	Olfactory receptors, family 4	151
31264	OR4A45P	olfactory receptor family 4 subfamily A member 45 pseudogene	Approved			11p11.2			OR4	Olfactory receptors, family 4	151
31265	OR4A46P	olfactory receptor family 4 subfamily A member 46 pseudogene	Approved			11p11.2			OR4	Olfactory receptors, family 4	151
31266	OR4A47	olfactory receptor family 4 subfamily A member 47	Approved			11p11.2	BK004380	NM_001005512	OR4	Olfactory receptors, family 4	151
31267	OR4A48P	olfactory receptor family 4 subfamily A member 48 pseudogene	Approved			11p11.2			OR4	Olfactory receptors, family 4	151
31268	OR4A49P	olfactory receptor family 4 subfamily A member 49 pseudogene	Approved			11p11.12			OR4	Olfactory receptors, family 4	151
15161	OR4A4P	olfactory receptor family 4 subfamily A member 4 pseudogene	Approved	OR4A4		11q11			OR4	Olfactory receptors, family 4	151
15162	OR4A5	olfactory receptor family 4 subfamily A member 5	Approved			11q11	AB065506	NM_001005272	OR4	Olfactory receptors, family 4	151
31269	OR4A50P	olfactory receptor family 4 subfamily A member 50 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15163	OR4A6P	olfactory receptor family 4 subfamily A member 6 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15164	OR4A7P	olfactory receptor family 4 subfamily A member 7 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15165	OR4A8	olfactory receptor family 4 subfamily A member 8 (gene/pseudogene)	Approved	OR4A8P		11q11			OR4	Olfactory receptors, family 4	151
15166	OR4A9P	olfactory receptor family 4 subfamily A member 9 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
8290	OR4B1	olfactory receptor family 4 subfamily B member 1	Approved		OST208	11p11.2	AB065848	NM_001005470	OR4	Olfactory receptors, family 4	151
8291	OR4B2P	olfactory receptor family 4 subfamily B member 2 pseudogene	Approved		hg449	11p11.2			OR4	Olfactory receptors, family 4	151
14800	OR4C10P	olfactory receptor family 4 subfamily C member 10 pseudogene	Approved			11p11.2			OR4	Olfactory receptors, family 4	151
15167	OR4C11	olfactory receptor family 4 subfamily C member 11	Approved	OR4C11P		11q11	AB065774	NM_001004700	OR4	Olfactory receptors, family 4	151
15168	OR4C12	olfactory receptor family 4 subfamily C member 12	Approved			11p11.12	BK004413	NM_001005270	OR4	Olfactory receptors, family 4	151
15169	OR4C13	olfactory receptor family 4 subfamily C member 13	Approved			11p11.12	AB065750	NM_001001955	OR4	Olfactory receptors, family 4	151
15170	OR4C14P	olfactory receptor family 4 subfamily C member 14 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15171	OR4C15	olfactory receptor family 4 subfamily C member 15	Approved			11q11	BK004319	NM_001001920	OR4	Olfactory receptors, family 4	151
15172	OR4C16	olfactory receptor family 4 subfamily C member 16 (gene/pseudogene)	Approved			11q11	AB065773	NM_001004701	OR4	Olfactory receptors, family 4	151
8292	OR4C1P	olfactory receptor family 4 subfamily C member 1 pseudogene	Approved	OR4C1	HTPCRX11, HSHTPCRX11	11q11	X64985	NG_002184	OR4	Olfactory receptors, family 4	151
14696	OR4C2P	olfactory receptor family 4 subfamily C member 2 pseudogene	Approved	OR4C8P		11p11.2			OR4	Olfactory receptors, family 4	151
14697	OR4C3	olfactory receptor family 4 subfamily C member 3	Approved			11p11.2	AB065567	NM_001004702	OR4	Olfactory receptors, family 4	151
31270	OR4C45	olfactory receptor family 4 subfamily C member 45 (gene/pseudogene)	Approved			11p11.12			OR4	Olfactory receptors, family 4	151
31271	OR4C46	olfactory receptor family 4 subfamily C member 46	Approved			11q11		NM_001004703	OR4	Olfactory receptors, family 4	151
31272	OR4C48P	olfactory receptor family 4 subfamily C member 48 pseudogene	Approved			11p11.12		NG_004421	OR4	Olfactory receptors, family 4	151
31273	OR4C49P	olfactory receptor family 4 subfamily C member 49 pseudogene	Approved			11p11.12			OR4	Olfactory receptors, family 4	151
14700	OR4C4P	olfactory receptor family 4 subfamily C member 4 pseudogene	Approved	OR4C17P, OR4C17	OR4C47P	11q12.1			OR4	Olfactory receptors, family 4	151
14702	OR4C5	olfactory receptor family 4 subfamily C member 5 (gene/pseudogene)	Approved	OR4C5P	OR4C5Q	11p11.2		NG_002247	OR4	Olfactory receptors, family 4	151
31274	OR4C50P	olfactory receptor family 4 subfamily C member 50 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
14743	OR4C6	olfactory receptor family 4 subfamily C member 6	Approved			11q11	CR593785	NM_001004704	OR4	Olfactory receptors, family 4	151
14768	OR4C7P	olfactory receptor family 4 subfamily C member 7 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
14796	OR4C9P	olfactory receptor family 4 subfamily C member 9 pseudogene	Approved			11p11.2			OR4	Olfactory receptors, family 4	151
8293	OR4D1	olfactory receptor family 4 subfamily D member 1	Approved	OR4D3	TPCR16	17q22	X89670		OR4	Olfactory receptors, family 4	151
15173	OR4D10	olfactory receptor family 4 subfamily D member 10	Approved	OR4D10P	OST711	11q12.1	AB065808	NM_001004705	OR4	Olfactory receptors, family 4	151
15174	OR4D11	olfactory receptor family 4 subfamily D member 11	Approved	OR4D11P		11q12.1	AB065810	NM_001004706	OR4	Olfactory receptors, family 4	151
19587	OR4D12P	olfactory receptor family 4 subfamily D member 12 pseudogene	Approved	OR7E103P		4p16.3		NG_004296	OR4	Olfactory receptors, family 4	151
8294	OR4D2	olfactory receptor family 4 subfamily D member 2	Approved			17q22			OR4	Olfactory receptors, family 4	151
14852	OR4D5	olfactory receptor family 4 subfamily D member 5	Approved			11q24.1	BK004316	NM_001001965	OR4	Olfactory receptors, family 4	151
15175	OR4D6	olfactory receptor family 4 subfamily D member 6	Approved			11q12.1	AB065803	NM_001004708	OR4	Olfactory receptors, family 4	151
15176	OR4D7P	olfactory receptor family 4 subfamily D member 7 pseudogene	Approved		OST724	11q12.1			OR4	Olfactory receptors, family 4	151
15177	OR4D8P	olfactory receptor family 4 subfamily D member 8 pseudogene	Approved			11q12.1			OR4	Olfactory receptors, family 4	151
15178	OR4D9	olfactory receptor family 4 subfamily D member 9	Approved			11q12.1	AB065861	NM_001004711	OR4	Olfactory receptors, family 4	151
8296	OR4E1	olfactory receptor family 4 subfamily E member 1 (gene/pseudogene)	Approved	OR4E1P		14q11.2			OR4	Olfactory receptors, family 4	151
8297	OR4E2	olfactory receptor family 4 subfamily E member 2	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
15076	OR4F13P	olfactory receptor family 4 subfamily F member 13 pseudogene	Approved			15q26.3	AB065564, AY792621	NR_046417	OR4	Olfactory receptors, family 4	151
15077	OR4F14P	olfactory receptor family 4 subfamily F member 14 pseudogene	Approved	OR4F14		15q26.3	AB065901		OR4	Olfactory receptors, family 4	151
15078	OR4F15	olfactory receptor family 4 subfamily F member 15	Approved			15q26.3	BK004405	NM_001001674	OR4	Olfactory receptors, family 4	151
15079	OR4F16	olfactory receptor family 4 subfamily F member 16	Approved			1p36.33		NM_001005277	OR4	Olfactory receptors, family 4	151
15381	OR4F17	olfactory receptor family 4 subfamily F member 17	Approved	OR4F19, OR4F11P, OR4F18		19p13.3	AC005605		OR4	Olfactory receptors, family 4	151
8298	OR4F1P	olfactory receptor family 4 subfamily F member 1 pseudogene	Approved	OR4F1	HSDJ0609N19	6p25.3			OR4	Olfactory receptors, family 4	151
19583	OR4F21	olfactory receptor family 4 subfamily F member 21	Approved	OR4F21P		8p23.3			OR4	Olfactory receptors, family 4	151
31229	OR4F28P	olfactory receptor family 4 subfamily F member 28 pseudogene	Approved			15q26.3			OR4	Olfactory receptors, family 4	151
31275	OR4F29	olfactory receptor family 4 subfamily F member 29	Approved			1p36.33		NM_001005221	OR4	Olfactory receptors, family 4	151
8299	OR4F2P	olfactory receptor family 4 subfamily F member 2 pseudogene	Approved		OR4F2, hs6M1-11, S191N21	11p15.5			OR4	Olfactory receptors, family 4	151
8300	OR4F3	olfactory receptor family 4 subfamily F member 3	Approved			5q35.3	AC004908		OR4	Olfactory receptors, family 4	151
8301	OR4F4	olfactory receptor family 4 subfamily F member 4	Approved		OR4F18	15q26.3		NM_001004195	OR4	Olfactory receptors, family 4	151
14825	OR4F5	olfactory receptor family 4 subfamily F member 5	Approved			1p36.33	AB065592	NM_001005484	OR4	Olfactory receptors, family 4	151
15372	OR4F6	olfactory receptor family 4 subfamily F member 6	Approved	OR4F12		15q26.3	AC025234		OR4	Olfactory receptors, family 4	151
15089	OR4F7P	olfactory receptor family 4 subfamily F member 7 pseudogene	Approved	OR4F10		6q27	AC069287		OR4	Olfactory receptors, family 4	151
15395	OR4F8P	olfactory receptor family 4 subfamily F member 8 pseudogene	Approved	OR4F20P, OR4F9P		19p13.3	AC016626		OR4	Olfactory receptors, family 4	151
31276	OR4G11P	olfactory receptor family 4 subfamily G member 11 pseudogene	Approved			1p36.33		NG_004423	OR4	Olfactory receptors, family 4	151
8302	OR4G1P	olfactory receptor family 4 subfamily G member 1 pseudogene	Approved	OR4G8P	OLB	19p13.3			OR4	Olfactory receptors, family 4	151
8303	OR4G2P	olfactory receptor family 4 subfamily G member 2 pseudogene	Approved	OR4G7P		15q26.3	AF282024	NG_003201	OR4	Olfactory receptors, family 4	151
8304	OR4G3P	olfactory receptor family 4 subfamily G member 3 pseudogene	Approved	OR4G3, OR4G5P	OLC, OLC-7501	19p13.3			OR4	Olfactory receptors, family 4	151
14822	OR4G4P	olfactory receptor family 4 subfamily G member 4 pseudogene	Approved			1p36.33		NG_004148	OR4	Olfactory receptors, family 4	151
15039	OR4G6P	olfactory receptor family 4 subfamily G member 6 pseudogene	Approved			15q26.3	AC005604		OR4	Olfactory receptors, family 4	151
19433	OR4H12P	olfactory receptor family 4 subfamily H member 12 pseudogene	Approved	OR4H12	C14orf14	14p13			OR4	Olfactory receptors, family 4	151
8312	OR4H6P	olfactory receptor family 4 subfamily H member 6 pseudogene	Approved	OR4H9P, OR4H10P, OR4H5P, OR4H11P, OR4H5, OR4H7, OR4H7P, OR4H2P, OR4H3P, OR4H11, OR4H2, OR4H3, OR4H1P, OR4H4P, OR4H10, OR4H4, OR4H8P, OR4H8	OR15-71, OR4H6, OR15-82, OR4H9, OR5-39, OR5-84, OR4-114, OR4-115, OR4-119, OR15-69, OR15-80, OR15-81, OR14-58	15q11.2	U86230		OR4	Olfactory receptors, family 4	151
14726	OR4K1	olfactory receptor family 4 subfamily K member 1	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
15402	OR4K11P	olfactory receptor family 4 subfamily K member 11 pseudogene	Approved		OR21-1	21q11.2	AF546490	NG_004161	OR4	Olfactory receptors, family 4	151
15403	OR4K12P	olfactory receptor family 4 subfamily K member 12 pseudogene	Approved		OR21-2	21q11.2		NG_004160	OR4	Olfactory receptors, family 4	151
15351	OR4K13	olfactory receptor family 4 subfamily K member 13	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
15352	OR4K14	olfactory receptor family 4 subfamily K member 14	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
15353	OR4K15	olfactory receptor family 4 subfamily K member 15	Approved		OR4K15Q	14q11.2			OR4	Olfactory receptors, family 4	151
15354	OR4K16P	olfactory receptor family 4 subfamily K member 16 pseudogene	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
15355	OR4K17	olfactory receptor family 4 subfamily K member 17	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
14728	OR4K2	olfactory receptor family 4 subfamily K member 2	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
14731	OR4K3	olfactory receptor family 4 subfamily K member 3 (gene/pseudogene)	Approved	OR4K3P		14q11.2			OR4	Olfactory receptors, family 4	151
14744	OR4K4P	olfactory receptor family 4 subfamily K member 4 pseudogene	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
14745	OR4K5	olfactory receptor family 4 subfamily K member 5	Approved			14q11.22	BK004355	NM_001005483	OR4	Olfactory receptors, family 4	151
14748	OR4K6P	olfactory receptor family 4 subfamily K member 6 pseudogene	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
14756	OR4K7P	olfactory receptor family 4 subfamily K member 7 pseudogene	Approved	OR4K10P		18p11.21	AC013659		OR4	Olfactory receptors, family 4	151
14787	OR4K8P	olfactory receptor family 4 subfamily K member 8 pseudogene	Approved	OR4K9P		18p11.21	AC015480		OR4	Olfactory receptors, family 4	151
15356	OR4L1	olfactory receptor family 4 subfamily L member 1	Approved	OR4L2P		14q11.2			OR4	Olfactory receptors, family 4	151
14735	OR4M1	olfactory receptor family 4 subfamily M member 1	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
15373	OR4M2	olfactory receptor family 4 subfamily M member 2	Approved			15q11.2	AC060768		OR4	Olfactory receptors, family 4	151
14740	OR4N1P	olfactory receptor family 4 subfamily N member 1 pseudogene	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
14742	OR4N2	olfactory receptor family 4 subfamily N member 2	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
15374	OR4N3P	olfactory receptor family 4 subfamily N member 3 pseudogene	Approved			15q11.2	AI809240		OR4	Olfactory receptors, family 4	151
15375	OR4N4	olfactory receptor family 4 subfamily N member 4	Approved			15q11.2	AI018459		OR4	Olfactory receptors, family 4	151
15358	OR4N5	olfactory receptor family 4 subfamily N member 5	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
14754	OR4P1P	olfactory receptor family 4 subfamily P member 1 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15180	OR4P4	olfactory receptor family 4 subfamily P member 4	Approved	OR4P3P		11q11	AB065775	NM_001004124	OR4	Olfactory receptors, family 4	151
15376	OR4Q1P	olfactory receptor family 4 subfamily Q member 1 pseudogene	Approved			15q11.2			OR4	Olfactory receptors, family 4	151
15359	OR4Q2	olfactory receptor family 4 subfamily Q member 2 (gene/pseudogene)	Approved	OR4Q2P		14q11.2			OR4	Olfactory receptors, family 4	151
15426	OR4Q3	olfactory receptor family 4 subfamily Q member 3	Approved	OR4Q4	C14orf13	14p13	AF179768		OR4	Olfactory receptors, family 4	151
14798	OR4R1P	olfactory receptor family 4 subfamily R member 1 pseudogene	Approved			11p11.2			OR4	Olfactory receptors, family 4	151
15181	OR4R2P	olfactory receptor family 4 subfamily R member 2 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15182	OR4R3P	olfactory receptor family 4 subfamily R member 3 pseudogene	Approved			11p11.12			OR4	Olfactory receptors, family 4	151
14705	OR4S1	olfactory receptor family 4 subfamily S member 1	Approved			11p11.2	AB065908	NM_001004725	OR4	Olfactory receptors, family 4	151
15183	OR4S2	olfactory receptor family 4 subfamily S member 2	Approved	OR4S2P	OST725	11q11	BK004390	NM_001004059	OR4	Olfactory receptors, family 4	151
15360	OR4T1P	olfactory receptor family 4 subfamily T member 1 pseudogene	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
15361	OR4U1P	olfactory receptor family 4 subfamily U member 1 pseudogene	Approved			14q11.2			OR4	Olfactory receptors, family 4	151
14736	OR4V1P	olfactory receptor family 4 subfamily V member 1 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
15405	OR4W1P	olfactory receptor family 4 subfamily W member 1 pseudogene	Approved			Xq25	Z69908		OR4	Olfactory receptors, family 4	151
14854	OR4X1	olfactory receptor family 4 subfamily X member 1 (gene/pseudogene)	Approved			11p11.2	AB065544	NM_001004726	OR4	Olfactory receptors, family 4	151
15184	OR4X2	olfactory receptor family 4 subfamily X member 2 (gene/pseudogene)	Approved			11p11.2	AB065847	NM_001004727	OR4	Olfactory receptors, family 4	151
31277	OR4X7P	olfactory receptor family 4 subfamily X member 7 pseudogene	Approved			11q11			OR4	Olfactory receptors, family 4	151
8319	OR5A1	olfactory receptor family 5 subfamily A member 1	Approved	OR5A1P	OST181	11q12.1	AB065804	NM_001004728	OR5	Olfactory receptors, family 5	152
15249	OR5A2	olfactory receptor family 5 subfamily A member 2	Approved			11q12.1	AB065805	NM_001001954	OR5	Olfactory receptors, family 5	152
15047	OR5AC1	olfactory receptor family 5 subfamily AC member 1 (gene/pseudogene)	Approved	OR5AC1P		3q11.2			OR5	Olfactory receptors, family 5	152
15431	OR5AC2	olfactory receptor family 5 subfamily AC member 2	Approved		HSA1	3q11.2	AF179759		OR5	Olfactory receptors, family 5	152
31284	OR5AC4P	olfactory receptor family 5 subfamily AC member 4 pseudogene	Approved			3q11.2			OR5	Olfactory receptors, family 5	152
14714	OR5AH1P	olfactory receptor family 5 subfamily AH member 1 pseudogene	Approved			19q13.43	AC006115		OR5	Olfactory receptors, family 5	152
15250	OR5AK1P	olfactory receptor family 5 subfamily AK member 1 pseudogene	Approved	OR5AK5P		11q12.1			OR5	Olfactory receptors, family 5	152
15251	OR5AK2	olfactory receptor family 5 subfamily AK member 2	Approved			11q12.1	AB065496	NM_001005323	OR5	Olfactory receptors, family 5	152
15252	OR5AK3P	olfactory receptor family 5 subfamily AK member 3 pseudogene	Approved	OR5AK3		11q12.1			OR5	Olfactory receptors, family 5	152
15253	OR5AK4P	olfactory receptor family 5 subfamily AK member 4 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
14844	OR5AL1	olfactory receptor family 5 subfamily AL member 1 (gene/pseudogene)	Approved	OR5AL1P		11q12.1			OR5	Olfactory receptors, family 5	152
14850	OR5AL2P	olfactory receptor family 5 subfamily AL member 2 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
15254	OR5AM1P	olfactory receptor family 5 subfamily AM member 1 pseudogene	Approved			11q12.1		NG_004211	OR5	Olfactory receptors, family 5	152
15255	OR5AN1	olfactory receptor family 5 subfamily AN member 1	Approved			11q12.1	AB065806	NM_001004729	OR5	Olfactory receptors, family 5	152
15256	OR5AN2P	olfactory receptor family 5 subfamily AN member 2 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
31285	OR5AO1P	olfactory receptor family 5 subfamily AO member 1 pseudogene	Approved			11q			OR5	Olfactory receptors, family 5	152
15257	OR5AP1P	olfactory receptor family 5 subfamily AP member 1 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
15258	OR5AP2	olfactory receptor family 5 subfamily AP member 2	Approved			11q12.1	AB065854	NM_001002925	OR5	Olfactory receptors, family 5	152
15259	OR5AQ1P	olfactory receptor family 5 subfamily AQ member 1 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
15260	OR5AR1	olfactory receptor family 5 subfamily AR member 1 (gene/pseudogene)	Approved			11q12.1	AB065740	NM_001004730	OR5	Olfactory receptors, family 5	152
15261	OR5AS1	olfactory receptor family 5 subfamily AS member 1	Approved			11q12.1	AB065543	NM_001001921	OR5	Olfactory receptors, family 5	152
15362	OR5AU1	olfactory receptor family 5 subfamily AU member 1	Approved			14q11.2	AL157687		OR5	Olfactory receptors, family 5	152
15406	OR5AW1P	olfactory receptor family 5 subfamily AW member 1 pseudogene	Approved			Xq26.2			OR5	Olfactory receptors, family 5	152
15262	OR5AZ1P	olfactory receptor family 5 subfamily AZ member 1 pseudogene	Approved			11q12.1	AP000743		OR5	Olfactory receptors, family 5	152
8320	OR5B10P	olfactory receptor family 5 subfamily B member 10 pseudogene	Approved	OR5B11P, OR5B4P, OR5B10, OR5B11, OR5B18P	OR13-67, OR13-34, OR13-64	11q12.1	U86223		OR5	Olfactory receptors, family 5	152
15432	OR5B12	olfactory receptor family 5 subfamily B member 12	Approved	OR5B12P, OR5B16	OST743	11q12.1	AB065851	NM_001004733	OR5	Olfactory receptors, family 5	152
15265	OR5B15P	olfactory receptor family 5 subfamily B member 15 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
15267	OR5B17	olfactory receptor family 5 subfamily B member 17	Approved	OR5B20P		11q12.1	AB065849	NM_001005489	OR5	Olfactory receptors, family 5	152
15269	OR5B19P	olfactory receptor family 5 subfamily B member 19 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
8322	OR5B1P	olfactory receptor family 5 subfamily B member 1 pseudogene	Approved	OR5B9P, OR5B9, OR5B5P, OR5B14P, OR5B7P, OR5B7, OR5B8, OR5B8P, OR5B5, OR5B6, OR5B6P	OR8-122, OR8-123, OR6-57, OR6-55, OR3-144, OR912-92	11q12.1	U86283		OR5	Olfactory receptors, family 5	152
8323	OR5B2	olfactory receptor family 5 subfamily B member 2	Approved		OST073	11q12.1	AB065852	NM_001005566	OR5	Olfactory receptors, family 5	152
19616	OR5B21	olfactory receptor family 5 subfamily B member 21	Approved			11q12.1		NM_001005218	OR5	Olfactory receptors, family 5	152
8324	OR5B3	olfactory receptor family 5 subfamily B member 3	Approved	OR5B13	OST129	11q12.1	AB065545	NM_001005469	OR5	Olfactory receptors, family 5	152
15270	OR5BA1P	olfactory receptor family 5 subfamily BA member 1 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
15271	OR5BB1P	olfactory receptor family 5 subfamily BB member 1 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
15272	OR5BC1P	olfactory receptor family 5 subfamily BC member 1 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
14843	OR5BD1P	olfactory receptor family 5 subfamily BD member 1 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
15273	OR5BE1P	olfactory receptor family 5 subfamily BE member 1 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
15407	OR5BH1P	olfactory receptor family 5 subfamily BH member 1 pseudogene	Approved	OR5BH2P		Xq26.2			OR5	Olfactory receptors, family 5	152
15434	OR5BJ1P	olfactory receptor family 5 subfamily BJ member 1 pseudogene	Approved		OST740	12q13.11		NG_004156	OR5	Olfactory receptors, family 5	152
14817	OR5BK1P	olfactory receptor family 5 subfamily BK member 1 pseudogene	Approved			12q13.11			OR5	Olfactory receptors, family 5	152
15275	OR5BL1P	olfactory receptor family 5 subfamily BL member 1 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
14835	OR5BM1P	olfactory receptor family 5 subfamily BM member 1 pseudogene	Approved			3q11.2	AC026100		OR5	Olfactory receptors, family 5	152
15276	OR5BN1P	olfactory receptor family 5 subfamily BN member 1 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
29194	OR5BN2P	olfactory receptor family 5 subfamily BN member 2 pseudogene	Approved			11q12			OR5	Olfactory receptors, family 5	152
15277	OR5BP1P	olfactory receptor family 5 subfamily BP member 1 pseudogene	Approved			11q12.1	AP001074		OR5	Olfactory receptors, family 5	152
15278	OR5BQ1P	olfactory receptor family 5 subfamily BQ member 1 pseudogene	Approved	OR5BQ2P		11q12.1			OR5	Olfactory receptors, family 5	152
15279	OR5BR1P	olfactory receptor family 5 subfamily BR member 1 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
19627	OR5BS1P	olfactory receptor family 5 subfamily BS member 1 pseudogene	Approved	OR5BS1		12q13.2		NG_004343	OR5	Olfactory receptors, family 5	152
19629	OR5BT1P	olfactory receptor family 5 subfamily BT member 1 pseudogene	Approved			12q13.2		NG_004300	OR5	Olfactory receptors, family 5	152
8331	OR5C1	olfactory receptor family 5 subfamily C member 1	Approved	OR5C2P	OR9-F, hRPK-465_F_21	9q33.2	AF399514		OR5	Olfactory receptors, family 5	152
15280	OR5D13	olfactory receptor family 5 subfamily D member 13 (gene/pseudogene)	Approved			11q11	BK004394	NM_001001967	OR5	Olfactory receptors, family 5	152
15281	OR5D14	olfactory receptor family 5 subfamily D member 14	Approved			11q11	AB065779	NM_001004735	OR5	Olfactory receptors, family 5	152
15282	OR5D15P	olfactory receptor family 5 subfamily D member 15 pseudogene	Approved			11q11			OR5	Olfactory receptors, family 5	152
15283	OR5D16	olfactory receptor family 5 subfamily D member 16	Approved			11q12.1	AB065783	NM_001005496	OR5	Olfactory receptors, family 5	152
15284	OR5D17P	olfactory receptor family 5 subfamily D member 17 pseudogene	Approved			11q11			OR5	Olfactory receptors, family 5	152
15285	OR5D18	olfactory receptor family 5 subfamily D member 18	Approved			11q12.1	AB065781	NM_001001952	OR5	Olfactory receptors, family 5	152
8335	OR5D2P	olfactory receptor family 5 subfamily D member 2 pseudogene	Approved	OR5D6P, OR5D10P, OR5D1P, OR5D5P, OR5D12P, OR5D8P, OR5D7P, OR5D9P, OR5D12, OR5D11P, OR5D11	OR11-7a, OR912-91, OR8-127, OR912-47, OR18-44, R5D9P, OR18-17, OR18-42, OR18-43, OR912-94, OR8-125	11q11	AF065858		OR5	Olfactory receptors, family 5	152
8336	OR5D3P	olfactory receptor family 5 subfamily D member 3 pseudogene	Approved	OR5D3, OR5D4	OR11-8b, OR11-8c	11q12	AF065861		OR5	Olfactory receptors, family 5	152
8342	OR5E1P	olfactory receptor family 5 subfamily E member 1 pseudogene	Approved	OR5E1	TPCR24, HSTPCR24	11p15.4	X89671		OR5	Olfactory receptors, family 5	152
8343	OR5F1	olfactory receptor family 5 subfamily F member 1	Approved		OR11-10	11q12.1	AF065863	NM_003697	OR5	Olfactory receptors, family 5	152
15286	OR5F2P	olfactory receptor family 5 subfamily F member 2 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
8344	OR5G1P	olfactory receptor family 5 subfamily G member 1 pseudogene	Approved	OR5G2P	OR11-104, OR93	11q12.1	AF065871		OR5	Olfactory receptors, family 5	152
15287	OR5G3	olfactory receptor family 5 subfamily G member 3 (gene/pseudogene)	Approved	OR5G6P, OR5G3P		11q12.1			OR5	Olfactory receptors, family 5	152
15288	OR5G4P	olfactory receptor family 5 subfamily G member 4 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
15289	OR5G5P	olfactory receptor family 5 subfamily G member 5 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
8346	OR5H1	olfactory receptor family 5 subfamily H member 1	Approved		HTPCRX14, HSHTPCRX14	3q11.2	X64988	NM_001005338	OR5	Olfactory receptors, family 5	152
31286	OR5H14	olfactory receptor family 5 subfamily H member 14	Approved			3q11.2			OR5	Olfactory receptors, family 5	152
31287	OR5H15	olfactory receptor family 5 subfamily H member 15	Approved			3q11.2			OR5	Olfactory receptors, family 5	152
14752	OR5H2	olfactory receptor family 5 subfamily H member 2	Approved			3q11.2			OR5	Olfactory receptors, family 5	152
14753	OR5H3P	olfactory receptor family 5 subfamily H member 3 pseudogene	Approved			3q11.2			OR5	Olfactory receptors, family 5	152
14763	OR5H4P	olfactory receptor family 5 subfamily H member 4 pseudogene	Approved			3q11.2			OR5	Olfactory receptors, family 5	152
14765	OR5H5P	olfactory receptor family 5 subfamily H member 5 pseudogene	Approved			3q11.2			OR5	Olfactory receptors, family 5	152
14767	OR5H6	olfactory receptor family 5 subfamily H member 6 (gene/pseudogene)	Approved			3q11.2	BK004374		OR5	Olfactory receptors, family 5	152
14771	OR5H7P	olfactory receptor family 5 subfamily H member 7 pseudogene	Approved			3q11.2			OR5	Olfactory receptors, family 5	152
14773	OR5H8	olfactory receptor family 5 subfamily H member 8 (gene/pseudogene)	Approved	OR5H8P		3q11.2			OR5	Olfactory receptors, family 5	152
8347	OR5I1	olfactory receptor family 5 subfamily I member 1	Approved		HSOlf1, OLF1	11q12.1	BC069093	NM_006637	OR5	Olfactory receptors, family 5	152
8348	OR5J1P	olfactory receptor family 5 subfamily J member 1 pseudogene	Approved	OR5J1	HTPCRH02	11q12.1	X64974		OR5	Olfactory receptors, family 5	152
19612	OR5J2	olfactory receptor family 5 subfamily J member 2	Approved			11q12.1	AB065595	NM_001005492	OR5	Olfactory receptors, family 5	152
31289	OR5J7P	olfactory receptor family 5 subfamily J member 7 pseudogene	Approved			11q			OR5	Olfactory receptors, family 5	152
8349	OR5K1	olfactory receptor family 5 subfamily K member 1	Approved		HTPCRX10, HSHTPCRX10	3q11.2	X64984		OR5	Olfactory receptors, family 5	152
14774	OR5K2	olfactory receptor family 5 subfamily K member 2	Approved			3q11.2	AC021660		OR5	Olfactory receptors, family 5	152
31290	OR5K3	olfactory receptor family 5 subfamily K member 3	Approved			3q11.2			OR5	Olfactory receptors, family 5	152
31291	OR5K4	olfactory receptor family 5 subfamily K member 4	Approved			3q11.2			OR5	Olfactory receptors, family 5	152
8350	OR5L1	olfactory receptor family 5 subfamily L member 1 (gene/pseudogene)	Approved		OST262	11q12.1	AB065780	NM_001004738	OR5	Olfactory receptors, family 5	152
8351	OR5L2	olfactory receptor family 5 subfamily L member 2	Approved		HTPCRX16, HSHTPCRX16	11q12.1	AB065782	NM_001004739	OR5	Olfactory receptors, family 5	152
8352	OR5M1	olfactory receptor family 5 subfamily M member 1	Approved		OST050	11q11	AB065742	NM_001004740	OR5	Olfactory receptors, family 5	152
15290	OR5M10	olfactory receptor family 5 subfamily M member 10	Approved			11q11	BK004515	NM_001004741	OR5	Olfactory receptors, family 5	152
15291	OR5M11	olfactory receptor family 5 subfamily M member 11	Approved		OR11-199	11q11	AP002517	NM_001005245	OR5	Olfactory receptors, family 5	152
15292	OR5M12P	olfactory receptor family 5 subfamily M member 12 pseudogene	Approved			11q12.1		NG_004190	OR5	Olfactory receptors, family 5	152
15293	OR5M13P	olfactory receptor family 5 subfamily M member 13 pseudogene	Approved			11q12.1	AF179769		OR5	Olfactory receptors, family 5	152
15057	OR5M14P	olfactory receptor family 5 subfamily M member 14 pseudogene	Approved	OR5M15P		4p13	AC013359		OR5	Olfactory receptors, family 5	152
14803	OR5M2P	olfactory receptor family 5 subfamily M member 2 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
14806	OR5M3	olfactory receptor family 5 subfamily M member 3	Approved			11q12.1	AB065746	NM_001004742	OR5	Olfactory receptors, family 5	152
14808	OR5M4P	olfactory receptor family 5 subfamily M member 4 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
14810	OR5M5P	olfactory receptor family 5 subfamily M member 5 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
14814	OR5M6P	olfactory receptor family 5 subfamily M member 6 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
14818	OR5M7P	olfactory receptor family 5 subfamily M member 7 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
14846	OR5M8	olfactory receptor family 5 subfamily M member 8	Approved			11q12.1	AB065744	NM_001005282	OR5	Olfactory receptors, family 5	152
15294	OR5M9	olfactory receptor family 5 subfamily M member 9	Approved			11q12.1	AB065747	NM_001004743	OR5	Olfactory receptors, family 5	152
14779	OR5P1P	olfactory receptor family 5 subfamily P member 1 pseudogene	Approved			11p15.4			OR5	Olfactory receptors, family 5	152
14783	OR5P2	olfactory receptor family 5 subfamily P member 2	Approved		JCG3	11p15.4	AF173006	NM_153444	OR5	Olfactory receptors, family 5	152
14784	OR5P3	olfactory receptor family 5 subfamily P member 3	Approved		JCG1	11p15.4	AF158377	NM_153445	OR5	Olfactory receptors, family 5	152
15295	OR5P4P	olfactory receptor family 5 subfamily P member 4 pseudogene	Approved		OST730	11p15.4			OR5	Olfactory receptors, family 5	152
14841	OR5R1	olfactory receptor family 5 subfamily R member 1 (gene/pseudogene)	Approved	OR5R1P		11q12.1	AB065504	NM_001004744	OR5	Olfactory receptors, family 5	152
15040	OR5S1P	olfactory receptor family 5 subfamily S member 1 pseudogene	Approved			2q37.3			OR5	Olfactory receptors, family 5	152
14821	OR5T1	olfactory receptor family 5 subfamily T member 1	Approved	OR5T1P		11q12.1	AB065962	NM_001004745	OR5	Olfactory receptors, family 5	152
15296	OR5T2	olfactory receptor family 5 subfamily T member 2	Approved			11q12.1	AB065838	NM_001004746	OR5	Olfactory receptors, family 5	152
15297	OR5T3	olfactory receptor family 5 subfamily T member 3	Approved		OR5T3Q	11q12.1	AB065837	NM_001004747	OR5	Olfactory receptors, family 5	152
13972	OR5V1	olfactory receptor family 5 subfamily V member 1	Approved		hs6M1-21	6p22.1			OR5	Olfactory receptors, family 5	152
15298	OR5W1P	olfactory receptor family 5 subfamily W member 1 pseudogene	Approved			11q12.1			OR5	Olfactory receptors, family 5	152
15299	OR5W2	olfactory receptor family 5 subfamily W member 2	Approved	OR5W2P, OR5W3P		11q12.1	BK004398	NM_001001960	OR5	Olfactory receptors, family 5	152
15185	OR51A10P	olfactory receptor family 51 subfamily A member 10 pseudogene	Approved	OR51A11P, OR51A13		11p15.4			OR51	Olfactory receptors, family 51	164
8316	OR51A1P	olfactory receptor family 51 subfamily A member 1 pseudogene	Approved			11p15.4		NG_002199	OR51	Olfactory receptors, family 51	164
14764	OR51A2	olfactory receptor family 51 subfamily A member 2	Approved			11p15.4	AB065797	NM_001004748	OR51	Olfactory receptors, family 51	164
14794	OR51A3P	olfactory receptor family 51 subfamily A member 3 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
14795	OR51A4	olfactory receptor family 51 subfamily A member 4	Approved			11p15.4	AB065798	NM_001005329	OR51	Olfactory receptors, family 51	164
14801	OR51A5P	olfactory receptor family 51 subfamily A member 5 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
15187	OR51A6P	olfactory receptor family 51 subfamily A member 6 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
15188	OR51A7	olfactory receptor family 51 subfamily A member 7	Approved			11p15.4	AB065525	NM_001004749	OR51	Olfactory receptors, family 51	164
15189	OR51A8P	olfactory receptor family 51 subfamily A member 8 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
15190	OR51A9P	olfactory receptor family 51 subfamily A member 9 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
31278	OR51AB1P	olfactory receptor family 51 subfamily AB member 1 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
14703	OR51B2	olfactory receptor family 51 subfamily B member 2 (gene/pseudogene)	Approved	OR51B1P		11p15.4	AF399503	NM_033180	OR51	Olfactory receptors, family 51	164
14706	OR51B3P	olfactory receptor family 51 subfamily B member 3 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
14708	OR51B4	olfactory receptor family 51 subfamily B member 4	Approved			11p15.4	BC069094	NM_033179	OR51	Olfactory receptors, family 51	164
19599	OR51B5	olfactory receptor family 51 subfamily B member 5	Approved			11p15.4	BK004430	NM_001005567	OR51	Olfactory receptors, family 51	164
19600	OR51B6	olfactory receptor family 51 subfamily B member 6	Approved			11p15.4		NM_001004750	OR51	Olfactory receptors, family 51	164
31279	OR51B8P	olfactory receptor family 51 subfamily B member 8 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
15191	OR51C1P	olfactory receptor family 51 subfamily C member 1 pseudogene	Approved	OR51C3P, OR51C2P	OST734	11p15.4			OR51	Olfactory receptors, family 51	164
31280	OR51C4P	olfactory receptor family 51 subfamily C member 4 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
15193	OR51D1	olfactory receptor family 51 subfamily D member 1	Approved		OR51D1Q	11p15.4	AB065855	NM_001004751	OR51	Olfactory receptors, family 51	164
15194	OR51E1	olfactory receptor family 51 subfamily E member 1	Approved	OR51E1P, OR52A3P, GPR164	GPR136	11p15.4	AY775731	NM_152430	OR51	Olfactory receptors, family 51	164
15195	OR51E2	olfactory receptor family 51 subfamily E member 2	Approved		PSGR	11p15.4	AY033942	NM_030774	OR51	Olfactory receptors, family 51	164
15196	OR51F1	olfactory receptor family 51 subfamily F member 1 (gene/pseudogene)	Approved	OR51F1P		11p15.4	BK004771	NM_001004752	OR51	Olfactory receptors, family 51	164
15197	OR51F2	olfactory receptor family 51 subfamily F member 2	Approved			11p15.4	BK004281	NM_001004753	OR51	Olfactory receptors, family 51	164
31281	OR51F3P	olfactory receptor family 51 subfamily F member 3 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
31282	OR51F4P	olfactory receptor family 51 subfamily F member 4 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
31283	OR51F5P	olfactory receptor family 51 subfamily F member 5 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
14738	OR51G1	olfactory receptor family 51 subfamily G member 1 (gene/pseudogene)	Approved	OR51G3P		11p15.4	AB065793	NM_001005237	OR51	Olfactory receptors, family 51	164
15198	OR51G2	olfactory receptor family 51 subfamily G member 2	Approved			11p15.4	AB065794	NM_001005238	OR51	Olfactory receptors, family 51	164
14833	OR51H1	olfactory receptor family 51 subfamily H member 1	Approved	OR51H1P		11p15.4			OR51	Olfactory receptors, family 51	164
15199	OR51H2P	olfactory receptor family 51 subfamily H member 2 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
15200	OR51I1	olfactory receptor family 51 subfamily I member 1	Approved			11p15.4	BK004429	NM_001005288	OR51	Olfactory receptors, family 51	164
15201	OR51I2	olfactory receptor family 51 subfamily I member 2	Approved			11p15.4	BK004381	NM_001004754	OR51	Olfactory receptors, family 51	164
14856	OR51J1	olfactory receptor family 51 subfamily J member 1 (gene/pseudogene)	Approved	OR51J2, OR51J1P		11p15.4		NG_002252	OR51	Olfactory receptors, family 51	164
15202	OR51K1P	olfactory receptor family 51 subfamily K member 1 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
14759	OR51L1	olfactory receptor family 51 subfamily L member 1	Approved			11p15.4	AB065799	NM_001004755	OR51	Olfactory receptors, family 51	164
14847	OR51M1	olfactory receptor family 51 subfamily M member 1	Approved			11p15.4	BK004382	NM_001004756	OR51	Olfactory receptors, family 51	164
14757	OR51N1P	olfactory receptor family 51 subfamily N member 1 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
14762	OR51P1P	olfactory receptor family 51 subfamily P member 1 pseudogene	Approved	OR51P2P		11p15.4			OR51	Olfactory receptors, family 51	164
14851	OR51Q1	olfactory receptor family 51 subfamily Q member 1 (gene/pseudogene)	Approved			11p15.4	AB065531	NM_001004757	OR51	Olfactory receptors, family 51	164
15203	OR51R1P	olfactory receptor family 51 subfamily R member 1 pseudogene	Approved			11p15.4			OR51	Olfactory receptors, family 51	164
15204	OR51S1	olfactory receptor family 51 subfamily S member 1	Approved			11p15.4	AB065796	NM_001004758	OR51	Olfactory receptors, family 51	164
15205	OR51T1	olfactory receptor family 51 subfamily T member 1	Approved			11p15.4	BK004283	NM_001004759	OR51	Olfactory receptors, family 51	164
19597	OR51V1	olfactory receptor family 51 subfamily V member 1	Approved	OR51A12		11p15.4	BK004432	NM_001004760	OR51	Olfactory receptors, family 51	164
8318	OR52A1	olfactory receptor family 52 subfamily A member 1	Approved		HPFH1OR	11p15.4	AF154673	NM_012375	OR52	Olfactory receptors, family 52	165
19579	OR52A4P	olfactory receptor family 52 subfamily A member 4 pseudogene	Approved	OR52A4		11p15.4		NG_029079	OR52	Olfactory receptors, family 52	165
19580	OR52A5	olfactory receptor family 52 subfamily A member 5	Approved			11p15.4	BK004433	NM_001005160	OR52	Olfactory receptors, family 52	165
15206	OR52B1P	olfactory receptor family 52 subfamily B member 1 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15207	OR52B2	olfactory receptor family 52 subfamily B member 2	Approved			11p15.4	AB065763	NM_001004052	OR52	Olfactory receptors, family 52	165
15208	OR52B3P	olfactory receptor family 52 subfamily B member 3 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15209	OR52B4	olfactory receptor family 52 subfamily B member 4 (gene/pseudogene)	Approved			11p15.4	AB065792	NM_001005161	OR52	Olfactory receptors, family 52	165
15210	OR52B5P	olfactory receptor family 52 subfamily B member 5 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15211	OR52B6	olfactory receptor family 52 subfamily B member 6	Approved			11p15.4	AB065858	NM_001005162	OR52	Olfactory receptors, family 52	165
15212	OR52D1	olfactory receptor family 52 subfamily D member 1	Approved			11p15.4	BK004276	NM_001005163	OR52	Olfactory receptors, family 52	165
14766	OR52E1	olfactory receptor family 52 subfamily E member 1 (gene/pseudogene)	Approved	OR52E1P		11p15.4			OR52	Olfactory receptors, family 52	165
14769	OR52E2	olfactory receptor family 52 subfamily E member 2	Approved			11p15.4	AB065800	NM_001005164	OR52	Olfactory receptors, family 52	165
14793	OR52E3P	olfactory receptor family 52 subfamily E member 3 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15213	OR52E4	olfactory receptor family 52 subfamily E member 4	Approved			11p15.4	AB065817	NM_001005165	OR52	Olfactory receptors, family 52	165
15214	OR52E5	olfactory receptor family 52 subfamily E member 5	Approved			11p15.4	AB065536	NM_001005166	OR52	Olfactory receptors, family 52	165
15215	OR52E6	olfactory receptor family 52 subfamily E member 6	Approved			11p15.4	AB065815	NM_001005167	OR52	Olfactory receptors, family 52	165
15216	OR52E7P	olfactory receptor family 52 subfamily E member 7 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15217	OR52E8	olfactory receptor family 52 subfamily E member 8	Approved			11p15.4	BK004301	NM_001005168	OR52	Olfactory receptors, family 52	165
15218	OR52H1	olfactory receptor family 52 subfamily H member 1	Approved			11p15.4	AB065802	NM_001005289	OR52	Olfactory receptors, family 52	165
15219	OR52H2P	olfactory receptor family 52 subfamily H member 2 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15220	OR52I1	olfactory receptor family 52 subfamily I member 1	Approved			11p15.4	BK004371	NM_001005169	OR52	Olfactory receptors, family 52	165
15221	OR52I2	olfactory receptor family 52 subfamily I member 2	Approved			11p15.4	BK004264	NM_001005170	OR52	Olfactory receptors, family 52	165
14760	OR52J1P	olfactory receptor family 52 subfamily J member 1 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
14797	OR52J2P	olfactory receptor family 52 subfamily J member 2 pseudogene	Approved	OR52J4P		11p15.4			OR52	Olfactory receptors, family 52	165
14799	OR52J3	olfactory receptor family 52 subfamily J member 3	Approved			11p15.4	AB065530	NM_001001916	OR52	Olfactory receptors, family 52	165
15222	OR52K1	olfactory receptor family 52 subfamily K member 1	Approved			11p15.4	AB065790	NM_001005171	OR52	Olfactory receptors, family 52	165
15223	OR52K2	olfactory receptor family 52 subfamily K member 2	Approved			11p15.4	AB065791	NM_001005172	OR52	Olfactory receptors, family 52	165
15224	OR52K3P	olfactory receptor family 52 subfamily K member 3 pseudogene	Approved			11p15.4	AF143328		OR52	Olfactory receptors, family 52	165
14785	OR52L1	olfactory receptor family 52 subfamily L member 1	Approved			11p15.4	AB065819	NM_001005173	OR52	Olfactory receptors, family 52	165
14788	OR52L2P	olfactory receptor family 52 subfamily L member 2 pseudogene	Approved	OR52L2		11p15.4			OR52	Olfactory receptors, family 52	165
15225	OR52M1	olfactory receptor family 52 subfamily M member 1	Approved	OR52M1P		11p15.4	AB065789	NM_001004137	OR52	Olfactory receptors, family 52	165
15226	OR52M2P	olfactory receptor family 52 subfamily M member 2 pseudogene	Approved	OR52M4		11p15.4			OR52	Olfactory receptors, family 52	165
14853	OR52N1	olfactory receptor family 52 subfamily N member 1	Approved			11p15.4	AB065538	NM_001001913	OR52	Olfactory receptors, family 52	165
15228	OR52N2	olfactory receptor family 52 subfamily N member 2	Approved			11p15.4	AB065816	NM_001005174	OR52	Olfactory receptors, family 52	165
15229	OR52N3P	olfactory receptor family 52 subfamily N member 3 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15230	OR52N4	olfactory receptor family 52 subfamily N member 4 (gene/pseudogene)	Approved			11p15.4	AB065813	NM_001005175	OR52	Olfactory receptors, family 52	165
15231	OR52N5	olfactory receptor family 52 subfamily N member 5	Approved		OR52N5Q	11p15.4	AB065535	NM_001001922	OR52	Olfactory receptors, family 52	165
15232	OR52P1P	olfactory receptor family 52 subfamily P member 1 pseudogene	Approved	OR52P1		11p15.4			OR52	Olfactory receptors, family 52	165
15233	OR52P2P	olfactory receptor family 52 subfamily P member 2 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15234	OR52Q1P	olfactory receptor family 52 subfamily Q member 1 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15235	OR52R1	olfactory receptor family 52 subfamily R member 1 (gene/pseudogene)	Approved			11p15.4	BK004282	NM_001005177	OR52	Olfactory receptors, family 52	165
14805	OR52S1P	olfactory receptor family 52 subfamily S member 1 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15236	OR52T1P	olfactory receptor family 52 subfamily T member 1 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15237	OR52U1P	olfactory receptor family 52 subfamily U member 1 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15238	OR52V1P	olfactory receptor family 52 subfamily V member 1 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15239	OR52W1	olfactory receptor family 52 subfamily W member 1	Approved	OR52W1P		11p15.4	AB065511	NM_001005178	OR52	Olfactory receptors, family 52	165
14790	OR52X1P	olfactory receptor family 52 subfamily X member 1 pseudogene	Approved			11p15.4			OR52	Olfactory receptors, family 52	165
15240	OR52Y1P	olfactory receptor family 52 subfamily Y member 1 pseudogene	Approved	OR52Y2P		11p15.4			OR52	Olfactory receptors, family 52	165
19596	OR52Z1	olfactory receptor family 52 subfamily Z member 1 (gene/pseudogene)	Approved	OR52Z1P		11p15.4		NG_004304	OR52	Olfactory receptors, family 52	165
15241	OR55B1P	olfactory receptor family 55 subfamily B member 1 pseudogene	Approved	OR55B2P, OR55C1P		11p15.4			OR55	Olfactory receptors, family 55	166
14781	OR56A1	olfactory receptor family 56 subfamily A member 1	Approved			11p15.4	AB065821	NM_001001917	OR56	Olfactory receptors, family 56	167
14786	OR56A3	olfactory receptor family 56 subfamily A member 3	Approved	OR56A6, OR56A3P		11p15.4		NM_001003443	OR56	Olfactory receptors, family 56	167
14791	OR56A4	olfactory receptor family 56 subfamily A member 4	Approved			11p15.4	BK004255	NM_001005179	OR56	Olfactory receptors, family 56	167
14792	OR56A5	olfactory receptor family 56 subfamily A member 5	Approved	OR56A5P		11p15.4		XM_001715165	OR56	Olfactory receptors, family 56	167
15244	OR56A7P	olfactory receptor family 56 subfamily A member 7 pseudogene	Approved			11p15.4			OR56	Olfactory receptors, family 56	167
15245	OR56B1	olfactory receptor family 56 subfamily B member 1	Approved	OR56B1P		11p15.4	BK004386	NM_001005180	OR56	Olfactory receptors, family 56	167
15246	OR56B2P	olfactory receptor family 56 subfamily B member 2 pseudogene	Approved	OR56B2		11p15.4			OR56	Olfactory receptors, family 56	167
15247	OR56B3P	olfactory receptor family 56 subfamily B member 3 pseudogene	Approved			11p15.4			OR56	Olfactory receptors, family 56	167
15248	OR56B4	olfactory receptor family 56 subfamily B member 4	Approved			11p15.4	AB065513	NM_001005181	OR56	Olfactory receptors, family 56	167
15301	OR6A2	olfactory receptor family 6 subfamily A member 2	Approved	OR6A2P, OR6A1	OR11-55	11p15.4	AB065822	NM_003696	OR6	Olfactory receptors, family 6	153
8354	OR6B1	olfactory receptor family 6 subfamily B member 1	Approved		OR7-3	7q35			OR6	Olfactory receptors, family 6	153
15041	OR6B2	olfactory receptor family 6 subfamily B member 2	Approved	OR6B2P		2q37.3		NM_001005853	OR6	Olfactory receptors, family 6	153
15042	OR6B3	olfactory receptor family 6 subfamily B member 3	Approved	OR6B3P	OR6B3Q	2q37.3			OR6	Olfactory receptors, family 6	153
8355	OR6C1	olfactory receptor family 6 subfamily C member 1	Approved		OST267	12q13.2	AF399506	NM_001005182	OR6	Olfactory receptors, family 6	153
15436	OR6C2	olfactory receptor family 6 subfamily C member 2	Approved		OR6C67	12q13.2	AF179766	NM_054105	OR6	Olfactory receptors, family 6	153
15437	OR6C3	olfactory receptor family 6 subfamily C member 3	Approved		OST709	12q13.2	AF179770		OR6	Olfactory receptors, family 6	153
19632	OR6C4	olfactory receptor family 6 subfamily C member 4	Approved			12q13.2	BK004261		OR6	Olfactory receptors, family 6	153
31292	OR6C5P	olfactory receptor family 6 subfamily C member 5 pseudogene	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31293	OR6C6	olfactory receptor family 6 subfamily C member 6	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31294	OR6C64P	olfactory receptor family 6 subfamily C member 64 pseudogene	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31295	OR6C65	olfactory receptor family 6 subfamily C member 65	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31296	OR6C66P	olfactory receptor family 6 subfamily C member 66 pseudogene	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31297	OR6C68	olfactory receptor family 6 subfamily C member 68	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31298	OR6C69P	olfactory receptor family 6 subfamily C member 69 pseudogene	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31299	OR6C70	olfactory receptor family 6 subfamily C member 70	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31300	OR6C71P	olfactory receptor family 6 subfamily C member 71 pseudogene	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31301	OR6C72P	olfactory receptor family 6 subfamily C member 72 pseudogene	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31302	OR6C73P	olfactory receptor family 6 subfamily C member 73 pseudogene	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31303	OR6C74	olfactory receptor family 6 subfamily C member 74	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31304	OR6C75	olfactory receptor family 6 subfamily C member 75	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
31305	OR6C76	olfactory receptor family 6 subfamily C member 76	Approved			12q13.2		NM_001005183	OR6	Olfactory receptors, family 6	153
31306	OR6C7P	olfactory receptor family 6 subfamily C member 7 pseudogene	Approved			12q13.2			OR6	Olfactory receptors, family 6	153
14849	OR6D1P	olfactory receptor family 6 subfamily D member 1 pseudogene	Approved			10q11.21	AL358394		OR6	Olfactory receptors, family 6	153
14739	OR6E1P	olfactory receptor family 6 subfamily E member 1 pseudogene	Approved			14q11.2			OR6	Olfactory receptors, family 6	153
15027	OR6F1	olfactory receptor family 6 subfamily F member 1	Approved		OST731	1q44	BK004460	NM_001005286	OR6	Olfactory receptors, family 6	153
14707	OR6J1	olfactory receptor family 6 subfamily J member 1 (gene/pseudogene)	Approved	OR6J2, OR6J1P		14q11.2	AC023226		OR6	Olfactory receptors, family 6	153
15028	OR6K1P	olfactory receptor family 6 subfamily K member 1 pseudogene	Approved			1q23.1			OR6	Olfactory receptors, family 6	153
15029	OR6K2	olfactory receptor family 6 subfamily K member 2	Approved			1q23.1	BK004196	NM_001005279	OR6	Olfactory receptors, family 6	153
15030	OR6K3	olfactory receptor family 6 subfamily K member 3	Approved			1q23.1	AB065633		OR6	Olfactory receptors, family 6	153
15031	OR6K4P	olfactory receptor family 6 subfamily K member 4 pseudogene	Approved			1q23.1			OR6	Olfactory receptors, family 6	153
15032	OR6K5P	olfactory receptor family 6 subfamily K member 5 pseudogene	Approved			1q23.1			OR6	Olfactory receptors, family 6	153
15033	OR6K6	olfactory receptor family 6 subfamily K member 6	Approved			1q23.1	BK004198	NM_001005184	OR6	Olfactory receptors, family 6	153
15124	OR6L1P	olfactory receptor family 6 subfamily L member 1 pseudogene	Approved			10q26.3	Z96427	NG_002282	OR6	Olfactory receptors, family 6	153
15125	OR6L2P	olfactory receptor family 6 subfamily L member 2 pseudogene	Approved			10q26.3		NG_004252	OR6	Olfactory receptors, family 6	153
14711	OR6M1	olfactory receptor family 6 subfamily M member 1	Approved			11q24.1	AB065762	NM_001005325	OR6	Olfactory receptors, family 6	153
14713	OR6M2P	olfactory receptor family 6 subfamily M member 2 pseudogene	Approved			11q24.1			OR6	Olfactory receptors, family 6	153
14741	OR6M3P	olfactory receptor family 6 subfamily M member 3 pseudogene	Approved			11q24.1			OR6	Olfactory receptors, family 6	153
15034	OR6N1	olfactory receptor family 6 subfamily N member 1	Approved			1q23.1	BK004199	NM_001005185	OR6	Olfactory receptors, family 6	153
15035	OR6N2	olfactory receptor family 6 subfamily N member 2	Approved			1q23.1	BK004200		OR6	Olfactory receptors, family 6	153
15036	OR6P1	olfactory receptor family 6 subfamily P member 1	Approved			1q23.1	BK004193		OR6	Olfactory receptors, family 6	153
15302	OR6Q1	olfactory receptor family 6 subfamily Q member 1 (gene/pseudogene)	Approved			11q12.1	AB065737	NM_001005186	OR6	Olfactory receptors, family 6	153
15037	OR6R1P	olfactory receptor family 6 subfamily R member 1 pseudogene	Approved			1q44			OR6	Olfactory receptors, family 6	153
31307	OR6R2P	olfactory receptor family 6 subfamily R member 2 pseudogene	Approved			8p21.3			OR6	Olfactory receptors, family 6	153
15363	OR6S1	olfactory receptor family 6 subfamily S member 1	Approved		OR6S1Q	14q11.2	AL163636		OR6	Olfactory receptors, family 6	153
14848	OR6T1	olfactory receptor family 6 subfamily T member 1	Approved			11q24.1	AB065759	NM_001005187	OR6	Olfactory receptors, family 6	153
19631	OR6U2P	olfactory receptor family 6 subfamily U member 2 pseudogene	Approved	OR6U1P		12q14.2		NG_004348	OR6	Olfactory receptors, family 6	153
15090	OR6V1	olfactory receptor family 6 subfamily V member 1	Approved		GPR138	7q34			OR6	Olfactory receptors, family 6	153
15091	OR6W1P	olfactory receptor family 6 subfamily W member 1 pseudogene	Approved	OR6W1	sdolf	7q34	AF286696		OR6	Olfactory receptors, family 6	153
14737	OR6X1	olfactory receptor family 6 subfamily X member 1	Approved			11q24.1	AB065510	NM_001005188	OR6	Olfactory receptors, family 6	153
14823	OR6Y1	olfactory receptor family 6 subfamily Y member 1	Approved	OR6Y2		1q23.1	BK004192	NM_001005189	OR6	Olfactory receptors, family 6	153
8356	OR7A10	olfactory receptor family 7 subfamily A member 10	Approved			19p13.1		NM_001005190	OR7	Olfactory receptors, family 7	154
8357	OR7A11P	olfactory receptor family 7 subfamily A member 11 pseudogene	Approved	OR7A11	OST527	19p13.12			OR7	Olfactory receptors, family 7	154
8361	OR7A15P	olfactory receptor family 7 subfamily A member 15 pseudogene	Approved	OR7A4P, OR7A16P, OR7A20P	OR19-134, OR19-1, OR19-146	19p13.12	U86253		OR7	Olfactory receptors, family 7	154
8363	OR7A17	olfactory receptor family 7 subfamily A member 17	Approved		HTPCRX19	19p13.12	X64993	NM_030901	OR7	Olfactory receptors, family 7	154
15399	OR7A18P	olfactory receptor family 7 subfamily A member 18 pseudogene	Approved			19p13.12			OR7	Olfactory receptors, family 7	154
15337	OR7A19P	olfactory receptor family 7 subfamily A member 19 pseudogene	Approved			12q13.11	AC008035		OR7	Olfactory receptors, family 7	154
8364	OR7A1P	olfactory receptor family 7 subfamily A member 1 pseudogene	Approved	OR7A6P	OR19-3, OLF4p, hg513	19p13.12			OR7	Olfactory receptors, family 7	154
8370	OR7A2P	olfactory receptor family 7 subfamily A member 2 pseudogene	Approved	OR7A7, OR7A2	hg1003, OR19-18, OLF4p	19p13.12			OR7	Olfactory receptors, family 7	154
8366	OR7A3P	olfactory receptor family 7 subfamily A member 3 pseudogene	Approved	OR7A12P, OR7A14P, OR7A14, OR7A13P	OR11-7b, OR19-12, OR14-59, OR14-11	19p13.12	AF065859		OR7	Olfactory receptors, family 7	154
8368	OR7A5	olfactory receptor family 7 subfamily A member 5	Approved		HTPCR2	19p13.1	X64976	NM_017506	OR7	Olfactory receptors, family 7	154
8371	OR7A8P	olfactory receptor family 7 subfamily A member 8 pseudogene	Approved	OR7A9P	OST042, HG83, OR19-11	19p13.12	AF399434		OR7	Olfactory receptors, family 7	154
8373	OR7C1	olfactory receptor family 7 subfamily C member 1	Approved	OR7C4	OR19-5	19p13.1	X89676		OR7	Olfactory receptors, family 7	154
8374	OR7C2	olfactory receptor family 7 subfamily C member 2	Approved	OR7C3	OR19-18	19p13.1	U86255		OR7	Olfactory receptors, family 7	154
31308	OR7D11P	olfactory receptor family 7 subfamily D member 11 pseudogene	Approved			19p13.2		NG_005822	OR7	Olfactory receptors, family 7	154
8377	OR7D1P	olfactory receptor family 7 subfamily D member 1 pseudogene	Approved	OR7D3P, OR7D3	OR19-A	19p13.2	U86251	NG_002212	OR7	Olfactory receptors, family 7	154
8378	OR7D2	olfactory receptor family 7 subfamily D member 2	Approved		OR19-4, HTPCRH03, FLJ38149	19p13.2	AK095468		OR7	Olfactory receptors, family 7	154
8380	OR7D4	olfactory receptor family 7 subfamily D member 4	Approved	OR7D4P	hg105, OR19-B	19p13.2			OR7	Olfactory receptors, family 7	154
15048	OR7E100P	olfactory receptor family 7 subfamily E member 100 pseudogene	Approved			3q13.2	AC024709		OR7	Olfactory receptors, family 7	154
15342	OR7E101P	olfactory receptor family 7 subfamily E member 101 pseudogene	Approved			13q14.13	AL157365		OR7	Olfactory receptors, family 7	154
15043	OR7E102P	olfactory receptor family 7 subfamily E member 102 pseudogene	Approved	OR7E102		2q11.1	AC009237		OR7	Olfactory receptors, family 7	154
15343	OR7E104P	olfactory receptor family 7 subfamily E member 104 pseudogene	Approved			13q21.31	AI799130		OR7	Olfactory receptors, family 7	154
15364	OR7E105P	olfactory receptor family 7 subfamily E member 105 pseudogene	Approved			14q22.1			OR7	Olfactory receptors, family 7	154
15365	OR7E106P	olfactory receptor family 7 subfamily E member 106 pseudogene	Approved	OR7E40P	OST215	14q22.1			OR7	Olfactory receptors, family 7	154
15117	OR7E108P	olfactory receptor family 7 subfamily E member 108 pseudogene	Approved		OST726	9q22.2	AL354862		OR7	Olfactory receptors, family 7	154
15118	OR7E109P	olfactory receptor family 7 subfamily E member 109 pseudogene	Approved		OST721	9q22.2			OR7	Olfactory receptors, family 7	154
8381	OR7E10P	olfactory receptor family 7 subfamily E member 10 pseudogene	Approved		OR11-1	8p23.1	AF399403		OR7	Olfactory receptors, family 7	154
15126	OR7E110P	olfactory receptor family 7 subfamily E member 110 pseudogene	Approved	OR7E68P, OR7E71P, OR7E72P, OR7E73P, OR7E74P, OR7E75P	hg674, OR912-109, OR912-46, OR912-108, OR912-110, hg523	10p13			OR7	Olfactory receptors, family 7	154
15344	OR7E111P	olfactory receptor family 7 subfamily E member 111 pseudogene	Approved			13q21.32	AC023058		OR7	Olfactory receptors, family 7	154
15127	OR7E115P	olfactory receptor family 7 subfamily E member 115 pseudogene	Approved		OST704	10p13	AL157391		OR7	Olfactory receptors, family 7	154
15122	OR7E116P	olfactory receptor family 7 subfamily E member 116 pseudogene	Approved		OST733	9q22.2			OR7	Olfactory receptors, family 7	154
15303	OR7E117P	olfactory receptor family 7 subfamily E member 117 pseudogene	Approved		OST716	11p15.4	AC060812		OR7	Olfactory receptors, family 7	154
8382	OR7E11P	olfactory receptor family 7 subfamily E member 11 pseudogene	Approved	OR7E144P	OR11-2	11q13.2	AF065853		OR7	Olfactory receptors, family 7	154
15049	OR7E121P	olfactory receptor family 7 subfamily E member 121 pseudogene	Approved			3p12.3	AC067827		OR7	Olfactory receptors, family 7	154
15050	OR7E122P	olfactory receptor family 7 subfamily E member 122 pseudogene	Approved		OST719	3p25.3	AC034187	NG_004265	OR7	Olfactory receptors, family 7	154
15098	OR7E125P	olfactory receptor family 7 subfamily E member 125 pseudogene	Approved		PJCG6	8p23.1	AF228730		OR7	Olfactory receptors, family 7	154
15304	OR7E126P	olfactory receptor family 7 subfamily E member 126 pseudogene	Approved		hg500, OR11-1	11q13.4	AI085560		OR7	Olfactory receptors, family 7	154
15305	OR7E128P	olfactory receptor family 7 subfamily E member 128 pseudogene	Approved			11q13.4	AP000719		OR7	Olfactory receptors, family 7	154
15052	OR7E129P	olfactory receptor family 7 subfamily E member 129 pseudogene	Approved			3q22.1		NG_004264	OR7	Olfactory receptors, family 7	154
8383	OR7E12P	olfactory receptor family 7 subfamily E member 12 pseudogene	Approved	OR7E58P, OR7E79P	OR11-3	11p15.4	AF065854		OR7	Olfactory receptors, family 7	154
15053	OR7E130P	olfactory receptor family 7 subfamily E member 130 pseudogene	Approved		OST702	3q21.2		NG_004314	OR7	Olfactory receptors, family 7	154
19557	OR7E136P	olfactory receptor family 7 subfamily E member 136 pseudogene	Approved	OR7E147P, OR7E139P		7p22.1		NG_004291	OR7	Olfactory receptors, family 7	154
8384	OR7E13P	olfactory receptor family 7 subfamily E member 13 pseudogene	Approved		OR11-4	11q14.2	AF065855		OR7	Olfactory receptors, family 7	154
19561	OR7E140P	olfactory receptor family 7 subfamily E member 140 pseudogene	Approved			12p13.31		NG_004309	OR7	Olfactory receptors, family 7	154
19618	OR7E145P	olfactory receptor family 7 subfamily E member 145 pseudogene	Approved			11q13.4		NG_004336	OR7	Olfactory receptors, family 7	154
19642	OR7E148P	olfactory receptor family 7 subfamily E member 148 pseudogene	Approved	OR7E150P		12p13		NG_004303	OR7	Olfactory receptors, family 7	154
19589	OR7E149P	olfactory receptor family 7 subfamily E member 149 pseudogene	Approved			12p13.31		NG_004297	OR7	Olfactory receptors, family 7	154
8385	OR7E14P	olfactory receptor family 7 subfamily E member 14 pseudogene	Approved	OR7E151P	OR11-5	11p15.1	AF065856		OR7	Olfactory receptors, family 7	154
31309	OR7E154P	olfactory receptor family 7 subfamily E member 154 pseudogene	Approved			8p23.1			OR7	Olfactory receptors, family 7	154
31310	OR7E155P	olfactory receptor family 7 subfamily E member 155 pseudogene	Approved			13q14.11			OR7	Olfactory receptors, family 7	154
31311	OR7E156P	olfactory receptor family 7 subfamily E member 156 pseudogene	Approved			13q21.31			OR7	Olfactory receptors, family 7	154
31231	OR7E157P	olfactory receptor family 7 subfamily E member 157 pseudogene	Approved			8p23.1			OR7	Olfactory receptors, family 7	154
31232	OR7E158P	olfactory receptor family 7 subfamily E member 158 pseudogene	Approved			8p23.1			OR7	Olfactory receptors, family 7	154
31312	OR7E159P	olfactory receptor family 7 subfamily E member 159 pseudogene	Approved			14q22.1			OR7	Olfactory receptors, family 7	154
8386	OR7E15P	olfactory receptor family 7 subfamily E member 15 pseudogene	Approved	OR7E80P, OR7E42P	OR11-392, OST001	8p23.1	AF065873		OR7	Olfactory receptors, family 7	154
31233	OR7E160P	olfactory receptor family 7 subfamily E member 160 pseudogene	Approved			8p23.1			OR7	Olfactory receptors, family 7	154
31234	OR7E161P	olfactory receptor family 7 subfamily E member 161 pseudogene	Approved			8p23.1			OR7	Olfactory receptors, family 7	154
28374	OR7E162P	olfactory receptor family 7 subfamily E member 162 pseudogene	Approved			4p16.3		NG_004863	OR7	Olfactory receptors, family 7	154
45040	OR7E163P	olfactory receptor family 7 subfamily E member 163 pseudogene	Approved			4p16.3			OR7	Olfactory receptors, family 7	154
8387	OR7E16P	olfactory receptor family 7 subfamily E member 16 pseudogene	Approved	OR7E60P, OR7E17P	OR19-133, OR19-9	19p13.2	U86252		OR7	Olfactory receptors, family 7	154
8389	OR7E18P	olfactory receptor family 7 subfamily E member 18 pseudogene	Approved	OR7E61, OR7E98P	OR19-14, TPCR26	19p13.2			OR7	Olfactory receptors, family 7	154
8390	OR7E19P	olfactory receptor family 7 subfamily E member 19 pseudogene	Approved	OR7E65	OR19-7	19p13.2			OR7	Olfactory receptors, family 7	154
8391	OR7E1P	olfactory receptor family 7 subfamily E member 1 pseudogene	Approved			11q13.2			OR7	Olfactory receptors, family 7	154
8393	OR7E21P	olfactory receptor family 7 subfamily E member 21 pseudogene	Approved	OR7E49P, OR7E127P	OR4DG, OST035	3p13			OR7	Olfactory receptors, family 7	154
8394	OR7E22P	olfactory receptor family 7 subfamily E member 22 pseudogene	Approved		OR6DG, OR3.6	3p12.3	AF042089		OR7	Olfactory receptors, family 7	154
8395	OR7E23P	olfactory receptor family 7 subfamily E member 23 pseudogene	Approved	OR7E92P	OR21-3	21q22.11	AF399396		OR7	Olfactory receptors, family 7	154
8396	OR7E24	olfactory receptor family 7 subfamily E member 24	Approved	OR7E24P	OR19-8, HSHT2, OR7E24Q	19p13.2	Y10529		OR7	Olfactory receptors, family 7	154
8397	OR7E25P	olfactory receptor family 7 subfamily E member 25 pseudogene	Approved		OR19-C, CIT-B-440L2	19p13.2			OR7	Olfactory receptors, family 7	154
8398	OR7E26P	olfactory receptor family 7 subfamily E member 26 pseudogene	Approved	OR7E67P, OR7E69P, OR7E70P, OR7E68P	OR1-51, OR1-72, OR1-73, OR912-95	10p13	U86301		OR7	Olfactory receptors, family 7	154
8400	OR7E28P	olfactory receptor family 7 subfamily E member 28 pseudogene	Approved	OR7E133P, OR7E107P, OR7E27P	OST128, hg616	2q24.1			OR7	Olfactory receptors, family 7	154
8401	OR7E29P	olfactory receptor family 7 subfamily E member 29 pseudogene	Approved		OST032	3q21.2		NG_004130	OR7	Olfactory receptors, family 7	154
8402	OR7E2P	olfactory receptor family 7 subfamily E member 2 pseudogene	Approved	OR7F2P, OR7E51P	OR11-6, hg94	11q14.2	AF065857		OR7	Olfactory receptors, family 7	154
8404	OR7E31P	olfactory receptor family 7 subfamily E member 31 pseudogene	Approved	OR7E32P	OST205	9q22.2			OR7	Olfactory receptors, family 7	154
8406	OR7E33P	olfactory receptor family 7 subfamily E member 33 pseudogene	Approved		hg688	13q21.32	AL353580		OR7	Olfactory receptors, family 7	154
8408	OR7E35P	olfactory receptor family 7 subfamily E member 35 pseudogene	Approved	OR7E120	OST018	4p16.1		NG_004371	OR7	Olfactory receptors, family 7	154
8409	OR7E36P	olfactory receptor family 7 subfamily E member 36 pseudogene	Approved	OR7E119P	OST024	13q14.11	AA574056	NG_004129	OR7	Olfactory receptors, family 7	154
8410	OR7E37P	olfactory receptor family 7 subfamily E member 37 pseudogene	Approved		hg533	13q14.11	AL354833		OR7	Olfactory receptors, family 7	154
8411	OR7E38P	olfactory receptor family 7 subfamily E member 38 pseudogene	Approved	OR7E76	OST127	7q21.3			OR7	Olfactory receptors, family 7	154
8412	OR7E39P	olfactory receptor family 7 subfamily E member 39 pseudogene	Approved	OR7E138P	hg611	7p22.1			OR7	Olfactory receptors, family 7	154
8415	OR7E41P	olfactory receptor family 7 subfamily E member 41 pseudogene	Approved	OR7F6P, OR7E50P, OR7E95P	OR11-20, hg84, OR8-126	11p15.2	AF065867		OR7	Olfactory receptors, family 7	154
8417	OR7E43P	olfactory receptor family 7 subfamily E member 43 pseudogene	Approved		OR4-116	4p16.3	U86267		OR7	Olfactory receptors, family 7	154
8420	OR7E46P	olfactory receptor family 7 subfamily E member 46 pseudogene	Approved		OST379, MCEEP	2p13.3			OR7	Olfactory receptors, family 7	154
8421	OR7E47P	olfactory receptor family 7 subfamily E member 47 pseudogene	Approved		OR7E141	12q13.13	X87825	NG_004128	OR7	Olfactory receptors, family 7	154
8424	OR7E4P	olfactory receptor family 7 subfamily E member 4 pseudogene	Approved	OR7F4P	OR11-11a	11q13.4	AF065864		OR7	Olfactory receptors, family 7	154
8428	OR7E53P	olfactory receptor family 7 subfamily E member 53 pseudogene	Approved	OR7E78P, OR7E78, OR7E132P	OR3-143, OR3-142	3q21.2	U86262		OR7	Olfactory receptors, family 7	154
8430	OR7E55P	olfactory receptor family 7 subfamily E member 55 pseudogene	Approved	OR7E56P	OR2DG, OR3.2, OST013	3p13		NG_004370	OR7	Olfactory receptors, family 7	154
8434	OR7E59P	olfactory receptor family 7 subfamily E member 59 pseudogene	Approved	OR7E59, OR7E137P	OST119	7p22.1			OR7	Olfactory receptors, family 7	154
8435	OR7E5P	olfactory receptor family 7 subfamily E member 5 pseudogene	Approved	OR7F5P	OR11-12, FLJ31393	11q12.1	AK055955		OR7	Olfactory receptors, family 7	154
8438	OR7E62P	olfactory receptor family 7 subfamily E member 62 pseudogene	Approved	OR7E63P, OR7E64P, OR7E82P	OR7E62, OR2-53, OR7E63, OR7E64	2p13.3	U86259		OR7	Olfactory receptors, family 7	154
8442	OR7E66P	olfactory receptor family 7 subfamily E member 66 pseudogene	Approved	OR7E6P, OR7E20P	hg630, HG630, OR3DG, OR3.3	3p13			OR7	Olfactory receptors, family 7	154
8457	OR7E7P	olfactory receptor family 7 subfamily E member 7 pseudogene	Approved			7q21.3			OR7	Olfactory receptors, family 7	154
14688	OR7E83P	olfactory receptor family 7 subfamily E member 83 pseudogene	Approved	OR7E134P		4p16.1			OR7	Olfactory receptors, family 7	154
14690	OR7E84P	olfactory receptor family 7 subfamily E member 84 pseudogene	Approved	OR7E54P	OST185	4p16.1			OR7	Olfactory receptors, family 7	154
14692	OR7E85P	olfactory receptor family 7 subfamily E member 85 pseudogene	Approved	OR7E88P		4p16.1	AW009208		OR7	Olfactory receptors, family 7	154
14694	OR7E86P	olfactory receptor family 7 subfamily E member 86 pseudogene	Approved			4p16.1			OR7	Olfactory receptors, family 7	154
14709	OR7E87P	olfactory receptor family 7 subfamily E member 87 pseudogene	Approved	OR7E3P, OR7F3P	OR11-9	11q13.4	AP000867		OR7	Olfactory receptors, family 7	154
14730	OR7E89P	olfactory receptor family 7 subfamily E member 89 pseudogene	Approved			2q24.1			OR7	Olfactory receptors, family 7	154
8458	OR7E8P	olfactory receptor family 7 subfamily E member 8 pseudogene	Approved		OR11-11a	8p23.1	AB065553	NG_002207	OR7	Olfactory receptors, family 7	154
14733	OR7E90P	olfactory receptor family 7 subfamily E member 90 pseudogene	Approved	OR7E123P	OST705	2q24.1			OR7	Olfactory receptors, family 7	154
14747	OR7E91P	olfactory receptor family 7 subfamily E member 91 pseudogene	Approved			2p13.3	BC030991		OR7	Olfactory receptors, family 7	154
14780	OR7E93P	olfactory receptor family 7 subfamily E member 93 pseudogene	Approved	OR7E131P		3q21.2		NG_002225	OR7	Olfactory receptors, family 7	154
14789	OR7E94P	olfactory receptor family 7 subfamily E member 94 pseudogene	Approved			4q21.21	AC013662		OR7	Olfactory receptors, family 7	154
14815	OR7E96P	olfactory receptor family 7 subfamily E member 96 pseudogene	Approved			8p23.1	AC025126		OR7	Olfactory receptors, family 7	154
14834	OR7E97P	olfactory receptor family 7 subfamily E member 97 pseudogene	Approved			3q21.2		NG_002256	OR7	Olfactory receptors, family 7	154
15059	OR7E99P	olfactory receptor family 7 subfamily E member 99 pseudogene	Approved			4p16.3			OR7	Olfactory receptors, family 7	154
8465	OR7G1	olfactory receptor family 7 subfamily G member 1	Approved	OR7G1P	OR19-15	19p13.2			OR7	Olfactory receptors, family 7	154
31313	OR7G15P	olfactory receptor family 7 subfamily G member 15 pseudogene	Approved			19p13.2			OR7	Olfactory receptors, family 7	154
8466	OR7G2	olfactory receptor family 7 subfamily G member 2	Approved		OST260	19p13.2			OR7	Olfactory receptors, family 7	154
8467	OR7G3	olfactory receptor family 7 subfamily G member 3	Approved		OST085	19p13.2			OR7	Olfactory receptors, family 7	154
8468	OR7H1P	olfactory receptor family 7 subfamily H member 1 pseudogene	Approved		OR7H1	19p13.2	AF399427		OR7	Olfactory receptors, family 7	154
31314	OR7H2P	olfactory receptor family 7 subfamily H member 2 pseudogene	Approved			5q21.1			OR7	Olfactory receptors, family 7	154
15366	OR7K1P	olfactory receptor family 7 subfamily K member 1 pseudogene	Approved			14q12	AL132827		OR7	Olfactory receptors, family 7	154
14827	OR7L1P	olfactory receptor family 7 subfamily L member 1 pseudogene	Approved			Xq26.2			OR7	Olfactory receptors, family 7	154
15128	OR7M1P	olfactory receptor family 7 subfamily M member 1 pseudogene	Approved			10q26.3			OR7	Olfactory receptors, family 7	154
8469	OR8A1	olfactory receptor family 8 subfamily A member 1	Approved		OST025	11q24.2	BK004495	NM_001005194	OR8	Olfactory receptors, family 8	155
15306	OR8A2P	olfactory receptor family 8 subfamily A member 2 pseudogene	Approved			11q24.2			OR8	Olfactory receptors, family 8	155
31315	OR8A3P	olfactory receptor family 8 subfamily A member 3 pseudogene	Approved			11q			OR8	Olfactory receptors, family 8	155
14751	OR8B10P	olfactory receptor family 8 subfamily B member 10 pseudogene	Approved			11q24.2			OR8	Olfactory receptors, family 8	155
15307	OR8B12	olfactory receptor family 8 subfamily B member 12	Approved			11q24.2			OR8	Olfactory receptors, family 8	155
8470	OR8B1P	olfactory receptor family 8 subfamily B member 1 pseudogene	Approved	OR8B11P	OR11-561	11q24.2	AF065875		OR8	Olfactory receptors, family 8	155
8471	OR8B2	olfactory receptor family 8 subfamily B member 2	Approved			11q24.2	AB065826	NM_001005468	OR8	Olfactory receptors, family 8	155
8472	OR8B3	olfactory receptor family 8 subfamily B member 3	Approved			11q24.2	AB065827	NM_001005467	OR8	Olfactory receptors, family 8	155
8473	OR8B4	olfactory receptor family 8 subfamily B member 4 (gene/pseudogene)	Approved	OR8B4P		11q24.2	AB065831	NM_001005196	OR8	Olfactory receptors, family 8	155
8474	OR8B5P	olfactory receptor family 8 subfamily B member 5 pseudogene	Approved			11q25			OR8	Olfactory receptors, family 8	155
8475	OR8B6P	olfactory receptor family 8 subfamily B member 6 pseudogene	Approved			11q25			OR8	Olfactory receptors, family 8	155
8476	OR8B7P	olfactory receptor family 8 subfamily B member 7 pseudogene	Approved	OR8B13P		11q25			OR8	Olfactory receptors, family 8	155
8477	OR8B8	olfactory receptor family 8 subfamily B member 8	Approved		TPCR85	11q24.2	AF238488	NM_012378	OR8	Olfactory receptors, family 8	155
14746	OR8B9P	olfactory receptor family 8 subfamily B member 9 pseudogene	Approved			11q24.2	AF179765		OR8	Olfactory receptors, family 8	155
8478	OR8C1P	olfactory receptor family 8 subfamily C member 1 pseudogene	Approved	OR8C3P, OR8C4P	OR11-175, OR912-45, OR912-106	11q24.2	AF065872		OR8	Olfactory receptors, family 8	155
8481	OR8D1	olfactory receptor family 8 subfamily D member 1	Approved	OR8D3	OST004	11q24.2	AF238489	NM_001002917	OR8	Olfactory receptors, family 8	155
8482	OR8D2	olfactory receptor family 8 subfamily D member 2 (gene/pseudogene)	Approved			11q24.2	AF162668	NM_001002918	OR8	Olfactory receptors, family 8	155
14840	OR8D4	olfactory receptor family 8 subfamily D member 4	Approved			11q24.1	AB065761	NM_001005197	OR8	Olfactory receptors, family 8	155
14691	OR8F1P	olfactory receptor family 8 subfamily F member 1 pseudogene	Approved			11q24.2			OR8	Olfactory receptors, family 8	155
8484	OR8G1	olfactory receptor family 8 subfamily G member 1 (gene/pseudogene)	Approved	OR8G1P	TPCR25, HSTPCR25	11q24.2	AB065946	NM_001002905	OR8	Olfactory receptors, family 8	155
8485	OR8G2P	olfactory receptor family 8 subfamily G member 2 pseudogene	Approved	OR8G4, OR8G2	TPCR120, HSTPCR120, ORL206, ORL486	11q24.2	X89669	NM_001007249	OR8	Olfactory receptors, family 8	155
14698	OR8G3P	olfactory receptor family 8 subfamily G member 3 pseudogene	Approved			11q24.2			OR8	Olfactory receptors, family 8	155
19622	OR8G5	olfactory receptor family 8 subfamily G member 5	Approved	OR8G5P, OR8G6		11q24.2	BK004516	NM_001005198	OR8	Olfactory receptors, family 8	155
19625	OR8G7P	olfactory receptor family 8 subfamily G member 7 pseudogene	Approved			11q24.2		NG_004628	OR8	Olfactory receptors, family 8	155
14824	OR8H1	olfactory receptor family 8 subfamily H member 1	Approved			11q12.1	AB065836	NM_001005199	OR8	Olfactory receptors, family 8	155
15308	OR8H2	olfactory receptor family 8 subfamily H member 2	Approved			11q12.1	AB065657	NM_001005200	OR8	Olfactory receptors, family 8	155
15309	OR8H3	olfactory receptor family 8 subfamily H member 3	Approved			11q12.1	AB065840	NM_001005201	OR8	Olfactory receptors, family 8	155
14828	OR8I1P	olfactory receptor family 8 subfamily I member 1 pseudogene	Approved			11q12.1			OR8	Olfactory receptors, family 8	155
15310	OR8I2	olfactory receptor family 8 subfamily I member 2	Approved			11q12.1	AB065656	NM_001003750	OR8	Olfactory receptors, family 8	155
31316	OR8I4P	olfactory receptor family 8 subfamily I member 4 pseudogene	Approved			11q			OR8	Olfactory receptors, family 8	155
14855	OR8J1	olfactory receptor family 8 subfamily J member 1	Approved			11q12.1	AB065748	NM_001005205	OR8	Olfactory receptors, family 8	155
15311	OR8J2	olfactory receptor family 8 subfamily J member 2 (gene/pseudogene)	Approved	OR8J2P		11q12.1			OR8	Olfactory receptors, family 8	155
15312	OR8J3	olfactory receptor family 8 subfamily J member 3	Approved			11q12.1		NM_001004064	OR8	Olfactory receptors, family 8	155
14831	OR8K1	olfactory receptor family 8 subfamily K member 1	Approved			11q12.1	AB065835	NM_001002907	OR8	Olfactory receptors, family 8	155
14832	OR8K2P	olfactory receptor family 8 subfamily K member 2 pseudogene	Approved			11q12.1			OR8	Olfactory receptors, family 8	155
15313	OR8K3	olfactory receptor family 8 subfamily K member 3 (gene/pseudogene)	Approved			11q12.1	AB065541	NM_001005202	OR8	Olfactory receptors, family 8	155
15314	OR8K4P	olfactory receptor family 8 subfamily K member 4 pseudogene	Approved			11q12.1			OR8	Olfactory receptors, family 8	155
15315	OR8K5	olfactory receptor family 8 subfamily K member 5	Approved			11q12.1	BK004347	NM_001004058	OR8	Olfactory receptors, family 8	155
15316	OR8L1P	olfactory receptor family 8 subfamily L member 1 pseudogene	Approved			11q12.1			OR8	Olfactory receptors, family 8	155
15317	OR8Q1P	olfactory receptor family 8 subfamily Q member 1 pseudogene	Approved			11q24.2			OR8	Olfactory receptors, family 8	155
15318	OR8R1P	olfactory receptor family 8 subfamily R member 1 pseudogene	Approved			11q13.4	AP002351		OR8	Olfactory receptors, family 8	155
19628	OR8S1	olfactory receptor family 8 subfamily S member 1	Approved			12q13.2			OR8	Olfactory receptors, family 8	155
31317	OR8S21P	olfactory receptor family 8 subfamily S member 21 pseudogene	Approved			12q13.11			OR8	Olfactory receptors, family 8	155
19630	OR8T1P	olfactory receptor family 8 subfamily T member 1 pseudogene	Approved			12q13.11		NG_004301	OR8	Olfactory receptors, family 8	155
19611	OR8U1	olfactory receptor family 8 subfamily U member 1	Approved			11q12.1	AB065603	NM_001005204	OR8	Olfactory receptors, family 8	155
27538	OR8U8	olfactory receptor family 8 subfamily U member 8	Approved			11q1 alternate reference locus	JH159136	NM_001013356	OR8	Olfactory receptors, family 8	155
29166	OR8U9	olfactory receptor family 8 subfamily U member 9	Approved			11q1 alternate reference locus	JH159136	NM_001013357	OR8	Olfactory receptors, family 8	155
19613	OR8V1P	olfactory receptor family 8 subfamily V member 1 pseudogene	Approved			11q12.1		NG_004299	OR8	Olfactory receptors, family 8	155
31318	OR8X1P	olfactory receptor family 8 subfamily X member 1 pseudogene	Approved			11q24.2			OR8	Olfactory receptors, family 8	155
8486	OR9A1P	olfactory receptor family 9 subfamily A member 1 pseudogene	Approved	OR9A1	HTPCRX06, HSHTPCRX06	7q34	X64982		OR9	Olfactory receptors, family 9	156
15093	OR9A2	olfactory receptor family 9 subfamily A member 2	Approved			7q34			OR9	Olfactory receptors, family 9	156
15094	OR9A3P	olfactory receptor family 9 subfamily A member 3 pseudogene	Approved	OR9A6P		7q34			OR9	Olfactory receptors, family 9	156
15095	OR9A4	olfactory receptor family 9 subfamily A member 4	Approved			7q34		NM_001001656	OR9	Olfactory receptors, family 9	156
15319	OR9G1	olfactory receptor family 9 subfamily G member 1	Approved	OR9G5		11q12.1	AB065500	NM_001005213	OR9	Olfactory receptors, family 9	156
15320	OR9G2P	olfactory receptor family 9 subfamily G member 2 pseudogene	Approved	OR9G6		11q12.1			OR9	Olfactory receptors, family 9	156
15321	OR9G3P	olfactory receptor family 9 subfamily G member 3 pseudogene	Approved			11q12.1			OR9	Olfactory receptors, family 9	156
15322	OR9G4	olfactory receptor family 9 subfamily G member 4	Approved			11q12.1	BK004400	NM_001005284	OR9	Olfactory receptors, family 9	156
31940	OR9G9	olfactory receptor family 9 subfamily G member 9	Approved			11q11 alternate reference locus	JH159137	NM_001013358	OR9	Olfactory receptors, family 9	156
15038	OR9H1P	olfactory receptor family 9 subfamily H member 1 pseudogene	Approved			1q44			OR9	Olfactory receptors, family 9	156
14718	OR9I1	olfactory receptor family 9 subfamily I member 1	Approved			11q12.1	AB065733	NM_001005211	OR9	Olfactory receptors, family 9	156
15324	OR9I2P	olfactory receptor family 9 subfamily I member 2 pseudogene	Approved			11q12.1	AF179762		OR9	Olfactory receptors, family 9	156
15325	OR9I3P	olfactory receptor family 9 subfamily I member 3 pseudogene	Approved		OST714	11q12.1			OR9	Olfactory receptors, family 9	156
15338	OR9K1P	olfactory receptor family 9 subfamily K member 1 pseudogene	Approved			12q13.2			OR9	Olfactory receptors, family 9	156
15339	OR9K2	olfactory receptor family 9 subfamily K member 2	Approved			12q13.2	BK004326		OR9	Olfactory receptors, family 9	156
14761	OR9L1P	olfactory receptor family 9 subfamily L member 1 pseudogene	Approved	OR9L2P		11q12.1	AC018807		OR9	Olfactory receptors, family 9	156
15327	OR9M1P	olfactory receptor family 9 subfamily M member 1 pseudogene	Approved	OR5BG1P		11q12.1			OR9	Olfactory receptors, family 9	156
15096	OR9N1P	olfactory receptor family 9 subfamily N member 1 pseudogene	Approved			7q34			OR9	Olfactory receptors, family 9	156
15097	OR9P1P	olfactory receptor family 9 subfamily P member 1 pseudogene	Approved	OR9P2P		7q34			OR9	Olfactory receptors, family 9	156
14724	OR9Q1	olfactory receptor family 9 subfamily Q member 1	Approved			11q12.1	AB065734	NM_001005212	OR9	Olfactory receptors, family 9	156
15328	OR9Q2	olfactory receptor family 9 subfamily Q member 2	Approved	OR9Q2P		11q12.1	AB065859	NM_001005283	OR9	Olfactory receptors, family 9	156
15340	OR9R1P	olfactory receptor family 9 subfamily R member 1 pseudogene	Approved			12q13.2			OR9	Olfactory receptors, family 9	156
31288	OR9S24P	olfactory receptor family 9 subfamily S member 24 pseudogene	Approved	OR5J6P		2q37.3			OR9	Olfactory receptors, family 9	156
"

#################################
	OR_info_con <- textConnection(OR_info)
	OR_info <- read.table(OR_info_con, sep='\t', head=TRUE)
	close(OR_info_con)
	if(save_to_local)
	{
		file_to_save = "OR_gene_family_info.tab"
		text1 = "## The Olfactory receptors (OR) gene family data\n"
		text2 = "## Description of the OR gene family: http://www.genenames.org/cgi-bin/genefamilies/set/141\n"
		text3 = "## Data downloaded from: http://www.genenames.org/cgi-bin/genefamilies/set/141\n\n"
		cat(text1, text2, text3, file=file_to_save, sep='')
		write.table(OR_info, file = file_to_save, sep="\t", quote=FALSE, row.names=FALSE, append=TRUE)
	}
	
	OR_genes = toupper(OR_info[,2])
	return( OR_genes )
}




